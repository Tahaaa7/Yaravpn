# Yara — تغییرات این نسخه

- SNI Spoof: پیش‌فرض خاموش، بررسی گواهی با نام واقعی سرور (verifyPeerCertByName)، غیرفعال روی Reality/ECH
- لوگوی جدید YARA (آیکون لانچر، آیکون استور، منوی کناری)
- رابط شیشه‌ای: پس‌زمینه گرادیانی، کارت‌های شیشه‌ای، کره‌ی اتصال متحرک در صفحه‌ی اصلی
- دریافت خودکار کانفیگ از پنل غیرفعال است (آدرس پنل از برنامه حذف شد)
  آدرس در `AppConfig.YARA_PANEL_URL` قابل تغییر است.

## Yara UI redesign (Figma "VPN App UI")
- New flat dark UI (#101010 / #1E1E1E / accent #9475FF) with 3 tabs: Home, Speed, Servers (+ drawer menu tab).
- Home: selected-server card, animated connect ring (idle / connecting / connected), live download/upload speed, session timer.
- Speed: latency gauge, test connection / test all / sort.
- Servers: search pill, group chips, Figma-style server cards with signal bars.
- App renamed to "Yara"; new launcher/banner/store icons generated from the supplied logo.
- Auto-config panel: AppConfig.YARA_PANEL_URL = https://pp.tahashahrokhi.ir
- New: handler/TrafficMonitor.kt (live speed shared with the UI), ui/main/MainYaraUi.kt, MainYaraPages.kt.
- Removed: MainPlayerUi, MainHero, MainBottomBar, MainTopBar, MainGroupTab.
