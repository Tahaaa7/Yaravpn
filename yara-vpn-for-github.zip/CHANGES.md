# Yara — تغییرات این نسخه

- SNI Spoof: پیش‌فرض خاموش، بررسی گواهی با نام واقعی سرور (verifyPeerCertByName)، غیرفعال روی Reality/ECH
- لوگوی جدید YARA (آیکون لانچر، آیکون استور، منوی کناری)
- رابط شیشه‌ای: پس‌زمینه گرادیانی، کارت‌های شیشه‌ای، کره‌ی اتصال متحرک در صفحه‌ی اصلی
- دریافت خودکار کانفیگ از پنل غیرفعال است (آدرس پنل از برنامه حذف شد)
  آدرس در `AppConfig.YARA_PANEL_URL` قابل تغییر است.

## Yara UI redesign (reference: instagram post DD80TdmOBO2, slide 1)
- Palette sampled from the design: bg #050E14, cards #0C1A23, fields #0B1D28, accent mint-teal #3FB9A2.
- Home: header (menu + diamond actions menu), procedural Earth image (res/drawable-nodpi/yara_earth.webp),
  "Connected" + big HH:MM:SS timer, gradient power button (idle / connecting / connected),
  bottom card with flag, server, host, Change button, live download / upload speed.
- Select server: back header, search, Global / Special / Selected as three swipeable pages (Special = starred),
  Auto Selection switch (connects to the lowest tested latency), rounded sheet with server rows
  (round flag from the emoji in the name, 3-bar signal, star). Selected row is the light card.
- New: handler/TrafficMonitor.kt, ui/main/MainYaraUi.kt, MainYaraPages.kt; ViewModel favorites + auto select.
- App renamed "Yara", launcher/banner/store icons from the supplied logo, panel URL https://pp.tahashahrokhi.ir.
