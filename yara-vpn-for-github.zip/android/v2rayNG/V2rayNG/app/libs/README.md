# Xray / libv2ray core (required)

This folder must contain `libv2ray.aar` (and optionally other AARs/JARs).

## How to obtain

```bash
git clone --depth 1 https://github.com/2dust/AndroidLibXrayLite.git
cd AndroidLibXrayLite
# Follow that repo's README (usually needs Go + Android NDK)
# After build, copy the produced AAR here:
# cp path/to/libv2ray.aar  ../V2rayNG/app/libs/
```

Without this AAR the app will not compile / run the VPN core.

See also: `android/YARA-BUILD.md` at project root.
