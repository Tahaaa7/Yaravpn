package com.v2ray.ang.handler

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Live connection numbers shown on the home screen (speed, totals, connected time).
 *
 * The values are produced by the single traffic sampling loop in [NotificationManager]
 * (the core counters are reset on every read, so only one reader may exist) and consumed by the UI.
 */
data class TrafficSample(
    /** Proxy upload speed in bytes per second. */
    val upBps: Long = 0L,
    /** Proxy download speed in bytes per second. */
    val downBps: Long = 0L,
    /** Proxy bytes uploaded since the connection started. */
    val totalUp: Long = 0L,
    /** Proxy bytes downloaded since the connection started. */
    val totalDown: Long = 0L,
    /** Wall-clock millis when the connection started, 0 when disconnected. */
    val connectedSinceMs: Long = 0L,
)

object TrafficMonitor {
    private val _sample = MutableStateFlow(TrafficSample())
    val sample: StateFlow<TrafficSample> = _sample.asStateFlow()

    /** Called once when the core starts (not on a reload), so the timer survives activity recreation. */
    fun onConnected() {
        _sample.value = TrafficSample(connectedSinceMs = System.currentTimeMillis())
    }

    /** Publishes one sampling interval of proxy traffic. */
    fun publish(upBytes: Long, downBytes: Long, seconds: Double) {
        if (seconds <= 0.0) return
        _sample.update { current ->
            if (current.connectedSinceMs == 0L) return@update current
            current.copy(
                upBps = (upBytes / seconds).toLong(),
                downBps = (downBytes / seconds).toLong(),
                totalUp = current.totalUp + upBytes,
                totalDown = current.totalDown + downBytes,
            )
        }
    }

    /** Screen off: the sampler is paused, so the speed is unknown, but the connection is still up. */
    fun clearSpeed() {
        _sample.update { it.copy(upBps = 0L, downBps = 0L) }
    }

    /** Called when the connection is torn down. */
    fun reset() {
        _sample.value = TrafficSample()
    }
}
