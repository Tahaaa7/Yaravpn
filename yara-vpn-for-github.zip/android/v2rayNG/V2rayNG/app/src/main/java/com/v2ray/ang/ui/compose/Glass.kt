package com.v2ray.ang.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** YARA brand colors (taken from the logo). */
val YaraCyan = Color(0xFF38E1FF)
val YaraBlue = Color(0xFF1E6BFF)
val YaraDeep = Color(0xFF0A0F1E)

/**
 * "Liquid glass" surface: translucent gradient fill + soft top-left highlight
 * + hairline gradient border. Works on every API level (no RenderEffect needed).
 */
@Composable
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(22.dp),
    tint: Color = Color.Unspecified,
    strong: Boolean = false,
): Modifier {
    val dark = LocalDarkTheme.current
    val base = if (tint != Color.Unspecified) tint else if (dark) Color.White else Color.White
    val topAlpha = if (dark) (if (strong) 0.20f else 0.12f) else (if (strong) 0.78f else 0.58f)
    val bottomAlpha = if (dark) (if (strong) 0.08f else 0.04f) else (if (strong) 0.50f else 0.34f)
    val borderTop = if (dark) Color.White.copy(alpha = 0.42f) else Color.White.copy(alpha = 0.95f)
    val borderBottom = if (dark) Color.White.copy(alpha = 0.06f) else Color.White.copy(alpha = 0.30f)
    return this
        .clip(shape)
        .background(Brush.verticalGradient(listOf(base.copy(alpha = topAlpha), base.copy(alpha = bottomAlpha))))
        .border(
            width = 1.dp,
            brush = Brush.verticalGradient(listOf(borderTop, borderBottom)),
            shape = shape
        )
}

/** Full-screen ambient background with soft glowing orbs, so the glass has something to refract. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val dark = LocalDarkTheme.current
    val bgTop = if (dark) Color(0xFF0A1022) else Color(0xFFEAF3FF)
    val bgBottom = if (dark) Color(0xFF050813) else Color(0xFFD9E8FF)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(bgTop, bgBottom)))
            .drawBehind {
                val a = if (dark) 0.34f else 0.30f
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(YaraCyan.copy(alpha = a), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.12f),
                        radius = size.minDimension * 0.75f
                    ),
                    radius = size.minDimension * 0.75f,
                    center = Offset(size.width * 0.15f, size.height * 0.12f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(YaraBlue.copy(alpha = a + 0.06f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.55f),
                        radius = size.minDimension * 0.85f
                    ),
                    radius = size.minDimension * 0.85f,
                    center = Offset(size.width * 0.95f, size.height * 0.55f)
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Color(0xFF7A5BFF).copy(alpha = a - 0.12f), Color.Transparent),
                        center = Offset(size.width * 0.2f, size.height * 0.95f),
                        radius = size.minDimension * 0.7f
                    ),
                    radius = size.minDimension * 0.7f,
                    center = Offset(size.width * 0.2f, size.height * 0.95f)
                )
            }
    ) {
        content()
    }
}

val GlassCorner: Dp = 22.dp
