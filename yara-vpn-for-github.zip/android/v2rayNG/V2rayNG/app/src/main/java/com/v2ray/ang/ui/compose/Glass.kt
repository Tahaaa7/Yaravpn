package com.v2ray.ang.ui.compose

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Yara design tokens (from the Figma file "VPN App UI"). */
object Yara {
    // Palette sampled from the reference design (dark teal-black, mint-teal accent).
    val bg = Color(0xFF050E14)
    val surface = Color(0xFF0C1A23)
    val surfaceHigh = Color(0xFF12252F)
    val sheet = Color(0xFF0A1820)
    val field = Color(0xFF0B1D28)
    val rowSelected = Color(0xFFE7ECEE)
    val tabBar = Color(0xFF0C1A23)
    val circle = Color(0xFF12252F)
    val accent = Color(0xFF3FB9A2)
    val accentLight = Color(0xFF9DE3D2)
    val accentDark = Color(0xFF2A8F7E)
    val blue = Color(0xFF5AAFC8)
    val green = Color(0xFF3FB9A2)
    val amber = Color(0xFFF2B84B)
    val red = Color(0xFFFF6B6B)
    val textDim = Color(0xFF7F95A1)
    val textMuted = Color(0xFF5E7480)
    val stroke = Color(0xFF1C3340)

    val cardCorner: Dp = 16.dp
    val pillCorner: Dp = 14.dp
    val buttonCorner: Dp = 14.dp
}

/** Legacy brand names kept so older call sites still compile; they now map to the Yara palette. */
val YaraCyan = Yara.blue
val YaraBlue = Yara.accent
val YaraDeep = Yara.bg

/**
 * Flat "Yara card" surface (used to be the glass effect): solid #1E1E1E fill and a hairline border.
 * The signature is unchanged so every existing `.glass(...)` call restyles automatically.
 */
@Composable
fun Modifier.glass(
    shape: Shape = RoundedCornerShape(Yara.cardCorner),
    tint: Color = Color.Unspecified,
    strong: Boolean = false,
): Modifier {
    val dark = LocalDarkTheme.current
    val fill = when {
        tint != Color.Unspecified -> tint
        dark -> if (strong) Yara.surfaceHigh else Yara.surface
        else -> if (strong) Color(0xFFFFFFFF) else Color(0xFFFFFFFF).copy(alpha = 0.92f)
    }
    val border = if (dark) Color.White.copy(alpha = 0.06f) else Color.Black.copy(alpha = 0.08f)
    return this
        .clip(shape)
        .background(fill)
        .border(width = 1.dp, color = border, shape = shape)
}

/** Full-screen flat background (#101010) with a very faint purple glow at the top. */
@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    val dark = LocalDarkTheme.current
    val base = if (dark) Yara.bg else Color(0xFFF2F7F8)
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(base)
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(Yara.accent.copy(alpha = if (dark) 0.05f else 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.5f, -size.height * 0.02f),
                        radius = size.width * 0.9f
                    ),
                    radius = size.width * 0.9f,
                    center = Offset(size.width * 0.5f, -size.height * 0.02f)
                )
            }
    ) {
        content()
    }
}

val GlassCorner: Dp = Yara.cardCorner
