package com.v2ray.ang.ui.compose

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.AppConfig
import com.v2ray.ang.handler.MmkvManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private val LightColor = lightColorScheme(
    primary = Color(0xFF7B5CF0),
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFFE9E2FF),
    onPrimaryContainer = Color(0xFF22145C),
    secondary = Color(0xFF2B8FD6),
    onSecondary = Color(0xFFFFFFFF),
    secondaryContainer = Color(0xFFD7ECFB),
    onSecondaryContainer = Color(0xFF062B45),
    tertiary = Color(0xFF3E9B22),
    onTertiary = Color(0xFFFFFFFF),
    tertiaryContainer = Color(0xFFD8F5CB),
    onTertiaryContainer = Color(0xFF0D2E03),
    error = Color(0xFFBA1A1A),
    errorContainer = Color(0xFFFFDAD6),
    onError = Color(0xFFFFFFFF),
    onErrorContainer = Color(0xFF410002),
    background = Color(0xFFF6F4FC),
    onBackground = Color(0xFF1C1B1F),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF1C1B1F),
    surfaceVariant = Color(0xFFEAE6F5),
    onSurfaceVariant = Color(0xFF4F4B5C),
    outline = Color(0xFF7A7688),
    outlineVariant = Color(0xFFD0CCDC),
    inverseSurface = Color(0xFF313033),
    inverseOnSurface = Color(0xFFF4EFF4),
    inversePrimary = Color(0xFFC9B9FF),
    scrim = Color(0xFF000000),
    surfaceTint = Color(0xFF7B5CF0),
    surfaceContainerLowest = Color(0xFFFFFFFF),
    surfaceContainerLow = Color(0xFFF8F6FD),
    surfaceContainer = Color(0xFFF1EEF9),
    surfaceContainerHigh = Color(0xFFEBE7F5),
    surfaceContainerHighest = Color(0xFFE5E1F0),
)

/** Dark palette taken 1:1 from the Yara Figma design (background #101010, accent #9475FF). */
internal val DarkColor = darkColorScheme(
    primary = Yara.accent,
    onPrimary = Color(0xFFFFFFFF),
    primaryContainer = Color(0xFF2E2557),
    onPrimaryContainer = Color(0xFFE7DFFF),
    secondary = Yara.blue,
    onSecondary = Color(0xFF00243A),
    secondaryContainer = Color(0xFF1B3446),
    onSecondaryContainer = Color(0xFFD3ECFF),
    tertiary = Yara.green,
    onTertiary = Color(0xFF0C2A00),
    tertiaryContainer = Color(0xFF1F3A16),
    onTertiaryContainer = Color(0xFFD7F7C9),
    error = Color(0xFFFF6B6B),
    errorContainer = Color(0xFF4A1C1C),
    onError = Color(0xFF2A0000),
    onErrorContainer = Color(0xFFFFDAD6),
    background = Yara.bg,
    onBackground = Color(0xFFFFFFFF),
    surface = Yara.surface,
    onSurface = Color(0xFFFFFFFF),
    surfaceVariant = Yara.surfaceHigh,
    onSurfaceVariant = Yara.textDim,
    outline = Color(0xFF5B636B),
    outlineVariant = Color(0xFF303030),
    inverseSurface = Color(0xFFEDEDED),
    inverseOnSurface = Color(0xFF101010),
    inversePrimary = Color(0xFF5B3FD0),
    scrim = Color(0xFF000000),
    surfaceTint = Yara.accent,
    surfaceContainerLowest = Yara.bg,
    surfaceContainerLow = Color(0xFF171717),
    surfaceContainer = Yara.surface,
    surfaceContainerHigh = Color(0xFF262626),
    surfaceContainerHighest = Yara.surfaceHigh,
)

val colorPing = Color(0xFF8FE770)
val colorPingRed = Color(0xFFFF6B6B)
val colorConfigType = Color(0xFF77838F)
val colorFabActive = Color(0xFF9475FF)
val colorFabInactiveLight = Color(0xFF9C9C9C)
val colorFabInactiveDark = Color(0xFF5B636B)
val dividerColorLight = Color(0xFFE0E0E0) // Light Gray
val dividerColorDark = Color(0xFF424242) // Dark Gray

// Toast Colors 85%
val toastNormalBgLight = Color(0xD9353A3E) // Dark Gray
val toastNormalBgDark = Color(0xD94A4F54) // Darker Gray
val toastSuccessBg = Color(0xD9388E3C) // Green
val toastErrorBg = Color(0xD9D50000) // Red
val toastInfoBg = Color(0xD93F51B5) // Indigo Blue
val toastIconCircleBg = Color(0x33FFFFFF) // Semi-transparent White
val toastTextColor = Color.White // White

object ThemeManager {
    private val _themeMode = MutableStateFlow(
        MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "2") ?: "2"
    )
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    private val _dynamicColorEnabled = MutableStateFlow(
        MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    )
    val dynamicColorEnabled: StateFlow<Boolean> = _dynamicColorEnabled.asStateFlow()

    fun setThemeMode(mode: String) {
        MmkvManager.encodeSettings(AppConfig.PREF_UI_MODE_NIGHT, mode)
        _themeMode.value = mode
    }

    fun setDynamicColorEnabled(enabled: Boolean) {
        MmkvManager.encodeSettings(AppConfig.PREF_DYNAMIC_COLOR, enabled)
        _dynamicColorEnabled.value = enabled
    }

    fun refresh() {
        _themeMode.value =
            MmkvManager.decodeSettingsString(AppConfig.PREF_UI_MODE_NIGHT, "2") ?: "2"
        _dynamicColorEnabled.value =
            MmkvManager.decodeSettingsBool(AppConfig.PREF_DYNAMIC_COLOR, false)
    }
}

@Composable
fun resolveDarkTheme(): Boolean {
    val mode by ThemeManager.themeMode.collectAsState()
    return when (mode) {
        "1" -> false
        "2" -> true
        else -> isSystemInDarkTheme()
    }
}

val LocalDarkTheme = compositionLocalOf { false }

@Composable
fun AppTheme(
    darkTheme: Boolean = resolveDarkTheme(),
    content: @Composable () -> Unit
) {
    val dynamicColor by ThemeManager.dynamicColorEnabled.collectAsState()
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }

        darkTheme -> DarkColor
        else -> LightColor
    }
    val snackbarController = rememberAppSnackbarController()

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val activity = view.context as? Activity ?: return@SideEffect
            val window = activity.window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !darkTheme
                isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }

    CompositionLocalProvider(
        LocalDarkTheme provides darkTheme,
        LocalAppSnackbar provides snackbarController
    ) {
        MaterialTheme(
            // transparent background so the flat Yara background (GlassBackground) shows on every screen
            colorScheme = colorScheme.copy(background = Color.Transparent)
        ) {
            GlassBackground {
                AppSnackbarBridge(controller = snackbarController)
                content()
                AppSnackbarHost(hostState = snackbarController.hostState)
            }
        }
    }
}
