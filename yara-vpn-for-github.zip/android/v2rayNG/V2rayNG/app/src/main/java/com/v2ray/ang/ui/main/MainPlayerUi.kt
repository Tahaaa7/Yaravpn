package com.v2ray.ang.ui.main

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.GroupMapItem
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin
import kotlin.random.Random

/** Palette of the "music player" look: near-black canvas, soft purple, lavender-pink accent. */
internal object Pl {
    val bg = Color(0xFF050407)
    val glow = Color(0xFF22123F)
    val card = Color(0xFF0B0A0E)
    val cardBorder = Color(0xFF2B2931)
    val cardSel = Color(0xFF232227)
    val cardSelBorder = Color(0xFF5A5762)
    val field = Color(0xFF1B1A20)
    val circle = Color(0xFF17161B)
    val textDim = Color(0xFF9A97A3)
    val purple = Color(0xFF9B6BFF)
    val lav = Color(0xFFCDB9EE)
    val pink = Color(0xFFEBC1D8)
}

internal val PlayerColorScheme = darkColorScheme(
    primary = Pl.lav,
    onPrimary = Color(0xFF14101C),
    primaryContainer = Color(0xFF2B2338),
    onPrimaryContainer = Color(0xFFEDE3FF),
    secondary = Color(0xFFB794F4),
    onSecondary = Color(0xFF14101C),
    secondaryContainer = Color(0xFF241D31),
    onSecondaryContainer = Color(0xFFEDE3FF),
    background = Pl.bg,
    onBackground = Color(0xFFF3F1F7),
    surface = Color(0xFF16151A),
    onSurface = Color(0xFFF3F1F7),
    surfaceVariant = Color(0xFF1F1E25),
    onSurfaceVariant = Pl.textDim,
    outline = Color(0xFF4A4753),
    outlineVariant = Color(0xFF2B2931),
    surfaceContainerLowest = Color(0xFF0B0A0E),
    surfaceContainerLow = Color(0xFF121116),
    surfaceContainer = Color(0xFF1A191F),
    surfaceContainerHigh = Color(0xFF211F27),
    surfaceContainerHighest = Color(0xFF29272F),
)

// ───────────────────────────── Header with the animated vortex ─────────────────────────────

@Composable
internal fun PlayerHeader(
    title: String,
    subtitle: String,
    running: Boolean,
    onDrawer: () -> Unit,
    onMenu: () -> Unit,
    onTestAll: () -> Unit,
    onSort: () -> Unit,
    moreMenu: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val top = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Box(modifier.fillMaxWidth().height(top + 236.dp)) {
        VortexArt(
            running = running,
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 52.dp)
                .clip(RoundedCornerShape(bottomStart = 190.dp, bottomEnd = 190.dp))
        )

        Row(
            Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(start = 10.dp, end = 10.dp, top = 8.dp)
                .align(Alignment.TopCenter),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            HeaderIcon(R.drawable.ic_mp_hamburger, stringResource(R.string.acc_open_menu), 32.dp, onDrawer)
            Box {
                HeaderIcon(R.drawable.ic_mp_more, stringResource(R.string.acc_more), 32.dp, onMenu)
                moreMenu()
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .padding(start = 10.dp, end = 10.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            HeaderIcon(R.drawable.ic_mp_speed, stringResource(R.string.title_ping_all_server), 34.dp, onTestAll)
            HeaderIcon(R.drawable.ic_mp_sort, stringResource(R.string.title_sort_by_test_results), 34.dp, onSort)
        }

        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .padding(start = 72.dp, end = 72.dp, bottom = 50.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            AnimatedContent(
                targetState = title,
                transitionSpec = {
                    (fadeIn(tween(320)) + slideInVertically(tween(320)) { it / 3 }) togetherWith
                        (fadeOut(tween(180)) + slideOutVertically(tween(180)) { -it / 3 })
                },
                label = "player-title"
            ) { t ->
                Text(
                    t,
                    style = TextStyle(
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        shadow = Shadow(Color.Black, Offset(0f, 2f), 14f)
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(4.dp))
            Text(
                subtitle,
                style = TextStyle(
                    fontSize = 16.sp,
                    color = Color(0xFFD9D4E4),
                    shadow = Shadow(Color.Black, Offset(0f, 2f), 12f)
                ),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun HeaderIcon(res: Int, desc: String?, iconSize: Dp, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(52.dp)) {
        Icon(painterResource(res), desc, Modifier.size(iconSize), tint = Color.White)
    }
}

/** Procedural purple vortex: rotating spiral arms, a black void in the middle and twinkling stars. */
@Composable
private fun VortexArt(running: Boolean, modifier: Modifier = Modifier) {
    var angle by remember { mutableFloatStateOf(0f) }
    val speed by animateFloatAsState(
        targetValue = if (running) 46f else 10f,
        animationSpec = tween(1400),
        label = "vortex-speed"
    )
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            androidx.compose.runtime.withFrameNanos { now ->
                if (last != 0L) {
                    angle = (angle + speed * (now - last) / 1_000_000_000f) % 360f
                }
                last = now
            }
        }
    }
    val stars = remember {
        List(70) { i ->
            val r = Random(i * 7919)
            floatArrayOf(r.nextFloat(), r.nextFloat() * 0.85f, 0.6f + r.nextFloat() * 1.2f, r.nextFloat() * 6.28f)
        }
    }
    val colors = remember {
        listOf(Color(0xFFB57BFF), Color(0xFF7B3FE4), Color(0xFFD7A8FF))
    }
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = Offset(w / 2f, h * 0.46f)
        val big = w * 0.72f
        drawRect(
            Brush.radialGradient(
                listOf(Color(0xFF2A1450), Color(0xFF0E0618), Color.Transparent),
                center = c, radius = big
            )
        )
        rotate(angle, pivot = c) {
            for (i in 0 until 22) {
                val f = i / 21f
                val r = big * (0.14f + 0.86f * f)
                drawArc(
                    color = colors[i % 3].copy(alpha = 0.55f * (1f - f * 0.7f)),
                    startAngle = i * 27f,
                    sweepAngle = 70f + 60f * (1f - f),
                    useCenter = false,
                    topLeft = Offset(c.x - r, c.y - r),
                    size = Size(r * 2f, r * 2f),
                    style = Stroke(width = big * 0.05f * (0.6f + f), cap = StrokeCap.Round)
                )
            }
        }
        drawCircle(
            Brush.radialGradient(
                listOf(Color.Black, Color.Black.copy(alpha = 0.92f), Color.Transparent),
                center = c, radius = big * 0.30f
            ),
            radius = big * 0.30f, center = c
        )
        val rad = angle * (PI.toFloat() / 180f)
        stars.forEachIndexed { idx, s ->
            val a = 0.2f + 0.6f * abs(sin(rad * 3f + s[3] + idx))
            drawCircle(Color.White.copy(alpha = a), radius = s[2] * density, center = Offset(s[0] * w, s[1] * h))
        }
        drawRect(
            Brush.verticalGradient(
                listOf(Color.Transparent, Pl.bg),
                startY = h * 0.55f, endY = h
            )
        )
    }
}

// ───────────────────────────── Search bar ─────────────────────────────

@Composable
internal fun PlayerSearchBar(query: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp)
            .height(50.dp)
            .clip(RoundedCornerShape(25.dp))
            .background(Pl.field),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painterResource(R.drawable.ic_mp_search), null,
            Modifier.padding(start = 16.dp).size(24.dp), tint = Pl.textDim
        )
        Box(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            if (query.isEmpty()) {
                Text(stringResource(R.string.search_configs), fontSize = 17.sp, color = Pl.textDim, maxLines = 1)
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
                cursorBrush = SolidColor(Pl.lav),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            IconButton(onClick = { onChange("") }, Modifier.size(44.dp)) {
                Icon(painterResource(R.drawable.ic_mp_close), null, Modifier.size(20.dp), tint = Pl.textDim)
            }
        }
    }
}

// ───────────────────────────── Tabs (groups) + add button ─────────────────────────────

@Composable
internal fun PlayerTabs(
    groups: List<GroupMapItem>,
    selectedIndex: Int,
    mainViewModel: MainViewModel,
    onTabClick: (Int) -> Unit,
    onAdd: () -> Unit,
    addMenu: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        groups.forEachIndexed { index, group ->
            val flow = remember(group.id, mainViewModel) { mainViewModel.serversForGroup(group.id) }
            val servers by flow.collectAsStateWithLifecycle()
            val label = if (group.id.isEmpty()) group.remarks else "${group.remarks} (${servers.size})"
            PlayerTab(
                label = label,
                iconRes = if (index == 0) R.drawable.ic_mp_globe else R.drawable.ic_mp_cloud,
                selected = index == selectedIndex,
                onClick = { onTabClick(index) }
            )
        }
        Box {
            Box(
                Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Pl.circle)
                    .clickable(onClick = onAdd),
                contentAlignment = Alignment.Center
            ) {
                Icon(painterResource(R.drawable.ic_mp_add), null, Modifier.size(26.dp), tint = Pl.textDim)
            }
            addMenu()
        }
    }
}

@Composable
private fun PlayerTab(label: String, iconRes: Int, selected: Boolean, onClick: () -> Unit) {
    val color by animateColorAsState(if (selected) Color.White else Pl.textDim, tween(250), label = "tab-color")
    val scale by animateFloatAsState(if (selected) 1f else 0.94f, spring(Spring.DampingRatioMediumBouncy), label = "tab-scale")
    Row(
        Modifier
            .scale(scale)
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(iconRes), null, Modifier.size(28.dp), tint = color)
        Spacer(Modifier.width(8.dp))
        Text(label, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = color, maxLines = 1, softWrap = false)
    }
}

// ───────────────────────────── Floating controller ─────────────────────────────

@Composable
internal fun PlayerController(
    isRunning: Boolean,
    onToggle: () -> Unit,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onLeft: () -> Unit,
    onRight: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        CircleButton(R.drawable.ic_mp_refresh, stringResource(R.string.title_service_restart), onLeft)
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f).height(82.dp), contentAlignment = Alignment.Center) {
            val pill = RoundedCornerShape(50)
            Row(
                Modifier
                    .fillMaxWidth()
                    .height(58.dp)
                    .clip(pill)
                    .background(Pl.circle.copy(alpha = 0.95f))
                    .border(1.dp, Pl.cardBorder, pill),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onPrev, Modifier.size(64.dp)) {
                    Icon(painterResource(R.drawable.ic_mp_prev), null, Modifier.size(30.dp), tint = Color.White)
                }
                Spacer(Modifier.width(84.dp))
                IconButton(onClick = onNext, Modifier.size(64.dp)) {
                    Icon(painterResource(R.drawable.ic_mp_chevron), null, Modifier.size(30.dp), tint = Color.White)
                }
            }
            BigPlayButton(isRunning, onToggle)
        }
        Spacer(Modifier.width(10.dp))
        CircleButton(R.drawable.ic_mp_bolt, stringResource(R.string.title_ping_all_server), onRight)
    }
}

@Composable
private fun CircleButton(iconRes: Int, desc: String?, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "cb")
    Box(
        Modifier
            .size(54.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(Pl.circle.copy(alpha = 0.95f))
            .border(1.dp, Pl.cardBorder, CircleShape)
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(iconRes), desc, Modifier.size(28.dp), tint = Color.White)
    }
}

@Composable
private fun BigPlayButton(isRunning: Boolean, onClick: () -> Unit) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "bp")
    val pulse = rememberInfiniteTransition(label = "glow")
    val glow by pulse.animateFloat(
        initialValue = 0.22f, targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1600, easing = LinearEasing), RepeatMode.Reverse),
        label = "glow-a"
    )
    Box(
        Modifier
            .size(80.dp)
            .scale(scale)
            .drawGlow(if (isRunning) glow else 0.18f)
            .clip(CircleShape)
            .background(Brush.linearGradient(if (isRunning) listOf(Color(0xFF8EF5D0), Color(0xFF5AD1FF)) else listOf(Pl.lav, Pl.pink)))
            .clickable(interactionSource = src, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Crossfade(isRunning, animationSpec = tween(250), label = "bp-icon") { running ->
            Icon(
                painterResource(if (running) R.drawable.ic_mp_shield_check else R.drawable.ic_mp_power),
                null, Modifier.size(38.dp), tint = Color(0xFF111014)
            )
        }
    }
}

private fun Modifier.drawGlow(alpha: Float): Modifier = this.drawBehind {
    drawCircle(
        Brush.radialGradient(
            listOf(Pl.purple.copy(alpha = alpha), Color.Transparent),
            center = center, radius = size.minDimension * 0.95f
        ),
        radius = size.minDimension * 0.95f, center = center
    )
}

// ───────────────────────────── Drop-down menus ─────────────────────────────

@Composable
internal fun ImportDropdown(expanded: Boolean, onDismiss: () -> Unit, onAction: (MainAction) -> Unit) {
    val scroll = rememberScrollState()
    val maxH = LocalConfiguration.current.screenHeightDp.dp - 120.dp
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        scrollState = scroll,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.heightIn(max = maxH)
    ) {
        ImportMenuContent(onAction = { action -> onDismiss(); onAction(action) })
    }
}

@Composable
internal fun MoreDropdown(expanded: Boolean, onDismiss: () -> Unit, onSelected: (MainMoreMenuAction) -> Unit) {
    val scroll = rememberScrollState()
    val maxH = LocalConfiguration.current.screenHeightDp.dp - 120.dp
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        scrollState = scroll,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.heightIn(max = maxH)
    ) {
        MoreMenuContent { action -> onDismiss(); onSelected(action) }
    }
}

// ───────────────────────────── Thumbnail used by server cards ─────────────────────────────

@Composable
internal fun ServerThumb(seed: Int, label: String, spinning: Boolean, size: Dp) {
    val extra = if (spinning) {
        val t = rememberInfiniteTransition(label = "ring")
        val a by t.animateFloat(
            initialValue = 0f, targetValue = 360f,
            animationSpec = infiniteRepeatable(tween(6000, easing = LinearEasing)),
            label = "ring-a"
        )
        a
    } else 0f
    Box(
        Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.26f)),
        contentAlignment = Alignment.BottomCenter
    ) {
        Canvas(Modifier.fillMaxSize()) { drawRing(seed, extra) }
        Text(
            label,
            fontSize = (size.value * 0.16f).sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFE6D9FF),
            maxLines = 1,
            modifier = Modifier.padding(bottom = size * 0.06f)
        )
    }
}

private fun DrawScope.drawRing(seed: Int, extra: Float) {
    val w = size.width
    val h = size.height
    val c = Offset(w / 2f, h * 0.44f)
    val a = Color(0xFF8B5CF6)
    val b = Color(0xFFD8B4FE)
    drawRect(
        Brush.radialGradient(
            listOf(Color(0xFF2B1650), Color(0xFF0B0713)),
            center = c, radius = w * 0.85f
        )
    )
    val tilt = (abs(seed) % 50 - 25).toFloat()
    rotate(tilt + extra, pivot = c) {
        val rw = w * 0.64f
        val rh = h * 0.30f
        drawOval(
            a.copy(alpha = 0.28f),
            topLeft = Offset(c.x - rw / 2f - w * 0.03f, c.y - rh / 2f - w * 0.03f),
            size = Size(rw + w * 0.06f, rh + w * 0.06f),
            style = Stroke(width = w * 0.12f)
        )
        drawOval(
            Brush.sweepGradient(listOf(a, b, a, Color(0xFF4C1D95), a), center = c),
            topLeft = Offset(c.x - rw / 2f, c.y - rh / 2f),
            size = Size(rw, rh),
            style = Stroke(width = w * 0.06f)
        )
    }
}
