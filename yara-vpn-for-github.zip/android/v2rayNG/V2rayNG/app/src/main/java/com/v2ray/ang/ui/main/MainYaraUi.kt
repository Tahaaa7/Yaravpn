package com.v2ray.ang.ui.main

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.ui.compose.Yara
import kotlinx.coroutines.delay
import java.util.Locale

/** What the big power button is showing. */
internal enum class ConnectVisual { Idle, Connecting, Connected }

/** The three filters of the server list segmented control. */
internal enum class ServerFilter { Global, Special, Selected }

// ───────────────────────────── Flags ─────────────────────────────

/** Splits a leading flag emoji (two regional-indicator symbols) from a server name. */
internal fun splitFlag(remarks: String): Pair<String?, String> {
    val text = remarks.trim()
    if (text.isEmpty()) return null to text
    val first = text.codePointAt(0)
    if (first !in 0x1F1E6..0x1F1FF) return null to text
    val firstLen = Character.charCount(first)
    if (text.length <= firstLen) return null to text
    val second = text.codePointAt(firstLen)
    if (second !in 0x1F1E6..0x1F1FF) return null to text
    val end = firstLen + Character.charCount(second)
    val name = text.substring(end).trimStart(' ', '-', '|', '\u2022', '\u00B7', '_', ':')
    return text.substring(0, end) to name.ifBlank { text.substring(0, end) }
}

/**
 * Round country flag (the flag emoji clipped to a circle, like the reference design);
 * servers without a flag get a dark disc with the protocol initials.
 */
@Composable
internal fun FlagAvatar(flag: String?, fallback: String, size: Dp, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(size)
            .clip(CircleShape)
            .background(Yara.surfaceHigh),
        contentAlignment = Alignment.Center
    ) {
        if (flag != null) {
            Text(
                flag,
                style = TextStyle(fontSize = (size.value * 0.92f).sp, textAlign = TextAlign.Center),
                maxLines = 1,
                softWrap = false
            )
        } else {
            Text(
                fallback.take(3).uppercase(),
                style = TextStyle(
                    fontSize = (size.value * 0.3f).sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Yara.accent
                ),
                maxLines = 1
            )
        }
    }
}

// ───────────────────────────── Signal bars ─────────────────────────────

/** Three ascending bars; lit bars follow the measured latency. */
@Composable
internal fun SignalBars(
    delayMs: Long,
    litColor: Color,
    offColor: Color,
    modifier: Modifier = Modifier,
) {
    val level = when {
        delayMs <= 0L -> 0
        delayMs <= 300L -> 3
        delayMs <= 800L -> 2
        else -> 1
    }
    Canvas(modifier.size(width = 16.dp, height = 14.dp)) {
        val barW = size.width / 5f
        val radius = CornerRadius(barW / 2f, barW / 2f)
        for (i in 0 until 3) {
            val h = size.height * (0.42f + 0.29f * i)
            drawRoundRect(
                color = if (i < level) litColor else offColor,
                topLeft = Offset(i * barW * 2f, size.height - h),
                size = Size(barW, h),
                cornerRadius = radius
            )
        }
    }
}

// ───────────────────────────── Home ─────────────────────────────

/** Plain round icon button (no background), as in the reference header. */
@Composable
internal fun HeaderIcon(iconRes: Int, desc: String?, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(iconRes), desc, Modifier.size(22.dp), tint = Color.White.copy(alpha = 0.85f))
    }
}

/**
 * Big power button: soft translucent rings, a mint-teal gradient disc and a thin power glyph.
 * Connecting shows a rotating arc; connected adds a faint teal glow.
 */
@Composable
internal fun YaraPowerButton(
    visual: ConnectVisual,
    actionLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "power")
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing), RepeatMode.Restart),
        label = "spin"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val top by animateColorAsState(
        if (visual == ConnectVisual.Idle) Color(0xFF2B4A52) else Color(0xFFB4E6D8), tween(400), label = "top"
    )
    val bottom by animateColorAsState(
        if (visual == ConnectVisual.Idle) Color(0xFF16303A) else Color(0xFF2F9C87), tween(400), label = "bottom"
    )
    val glyph by animateColorAsState(
        if (visual == ConnectVisual.Idle) Yara.accent else Color(0xFF86D3C1), tween(400), label = "glyph"
    )
    Box(
        modifier
            .size(240.dp)
            .clip(CircleShape)
            .semantics { contentDescription = actionLabel; role = Role.Button }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val ringOuter = size.minDimension / 2f
            val ringMid = ringOuter * 0.89f
            val disc = ringOuter * 0.64f
            if (visual == ConnectVisual.Connected) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(Yara.accent.copy(alpha = 0.22f), Color.Transparent),
                        center = c, radius = ringOuter
                    ),
                    radius = ringOuter, center = c
                )
                drawCircle(
                    Yara.accent.copy(alpha = (1f - pulse) * 0.18f),
                    radius = ringMid + pulse * (ringOuter - ringMid), center = c,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
            drawCircle(Color.White.copy(alpha = 0.035f), radius = ringOuter, center = c)
            drawCircle(Color(0xFF0A1B24), radius = ringMid, center = c)
            drawCircle(Color.White.copy(alpha = 0.025f), radius = ringMid, center = c)
            drawCircle(
                Brush.linearGradient(
                    listOf(top, bottom),
                    start = Offset(c.x - disc, c.y - disc),
                    end = Offset(c.x + disc, c.y + disc)
                ),
                radius = disc, center = c
            )
            if (visual == ConnectVisual.Connecting) {
                val arcR = disc + 6.dp.toPx()
                rotate(spin, pivot = c) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0f to Color.Transparent, 1f to Yara.accentLight, center = c
                        ),
                        startAngle = 0f, sweepAngle = 360f, useCenter = false,
                        topLeft = Offset(c.x - arcR, c.y - arcR),
                        size = Size(arcR * 2f, arcR * 2f),
                        style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            // power glyph: open ring + vertical stroke
            val gr = disc * 0.36f
            val sw = 3.dp.toPx()
            drawArc(
                color = glyph, startAngle = -60f, sweepAngle = 300f, useCenter = false,
                topLeft = Offset(c.x - gr, c.y - gr + sw), size = Size(gr * 2f, gr * 2f),
                style = Stroke(width = sw, cap = StrokeCap.Round)
            )
            drawLine(
                color = glyph, start = Offset(c.x, c.y - gr - sw * 0.2f), end = Offset(c.x, c.y - gr * 0.05f),
                strokeWidth = sw, cap = StrokeCap.Round
            )
        }
    }
}

/** HH:MM:SS since the connection started; ticks once per second while [active]. */
@Composable
internal fun rememberElapsedText(sinceMs: Long, active: Boolean): String {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active, sinceMs) {
        while (active) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val secs = if (active && sinceMs > 0L) ((now - sinceMs) / 1000L).coerceAtLeast(0L) else 0L
    return String.format(Locale.US, "%02d:%02d:%02d", secs / 3600, (secs % 3600) / 60, secs % 60)
}

/** Bottom card of the home screen: selected server + Change, divider, download / upload. */
@Composable
internal fun YaraHomeCard(
    summary: SelectedServerSummary?,
    downText: String,
    upText: String,
    onChange: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val (flag, name) = splitFlag(summary?.remarks.orEmpty())
    val title = name.ifBlank { stringResource(R.string.yara_no_server) }
    val subtitle = summary?.let { listOf(it.protocol, it.host).filter { p -> p.isNotBlank() }.joinToString(" \u00B7 ") }.orEmpty()
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Yara.surface)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlagAvatar(flag, summary?.protocol ?: "Y", 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    title,
                    style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color.White),
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (subtitle.isNotEmpty()) {
                    Text(
                        subtitle,
                        style = TextStyle(fontSize = 12.sp, color = Yara.textDim),
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                }
            }
            Spacer(Modifier.width(8.dp))
            Box(
                Modifier
                    .height(34.dp)
                    .clip(RoundedCornerShape(17.dp))
                    .border(1.dp, Yara.stroke, RoundedCornerShape(17.dp))
                    .clickable(role = Role.Button, onClick = onChange)
                    .padding(horizontal = 18.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    stringResource(R.string.yara_change),
                    style = TextStyle(fontSize = 13.sp, color = Color.White.copy(alpha = 0.85f)),
                    maxLines = 1
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        HorizontalDivider(color = Yara.stroke.copy(alpha = 0.8f), thickness = 1.dp)
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth()) {
            SpeedCell(R.drawable.ic_y_arrow_down, downText, stringResource(R.string.yara_downloaded), Modifier.weight(1f))
            SpeedCell(R.drawable.ic_y_arrow_up, upText, stringResource(R.string.yara_uploaded), Modifier.weight(1f))
        }
    }
}

@Composable
private fun SpeedCell(iconRes: Int, value: String, label: String, modifier: Modifier = Modifier) {
    Row(modifier.semantics(mergeDescendants = true) { }, verticalAlignment = Alignment.CenterVertically) {
        Icon(painterResource(iconRes), null, Modifier.size(20.dp), tint = Yara.accent)
        Spacer(Modifier.width(10.dp))
        Column {
            Text(
                value,
                style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White),
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(label, style = TextStyle(fontSize = 12.sp, color = Yara.textDim), maxLines = 1)
        }
    }
}

// ───────────────────────────── Select server ─────────────────────────────

@Composable
internal fun YaraServersHeader(title: String, onBack: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .height(56.dp)
            .padding(horizontal = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        HeaderIcon(
            R.drawable.ic_y_chevron_left, stringResource(R.string.acc_back), onBack,
            Modifier.align(Alignment.CenterStart)
        )
        Text(
            title,
            style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color.White),
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
internal fun YaraSearchField(query: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(Yara.pillCorner))
            .background(Yara.field),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            painterResource(R.drawable.ic_y_search), null,
            Modifier.padding(start = 16.dp).size(20.dp), tint = Yara.textDim
        )
        Box(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            if (query.isEmpty()) {
                Text(
                    stringResource(R.string.yara_search),
                    style = TextStyle(fontSize = 15.sp, color = Yara.textDim), maxLines = 1
                )
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                cursorBrush = SolidColor(Yara.accent),
                modifier = Modifier.fillMaxWidth()
            )
        }
        if (query.isNotEmpty()) {
            Box(
                Modifier.size(44.dp).clickable(role = Role.Button) { onChange("") },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painterResource(R.drawable.ic_mp_close), stringResource(R.string.acc_back),
                    Modifier.size(18.dp), tint = Yara.textDim
                )
            }
        }
    }
}

/** Global / Special / Selected pill control; the active segment is filled teal. */
@Composable
internal fun YaraSegmented(selected: ServerFilter, onSelect: (ServerFilter) -> Unit, modifier: Modifier = Modifier) {
    val labels = listOf(
        ServerFilter.Global to stringResource(R.string.yara_global),
        ServerFilter.Special to stringResource(R.string.yara_special),
        ServerFilter.Selected to stringResource(R.string.yara_selected),
    )
    Row(
        modifier
            .fillMaxWidth()
            .height(52.dp)
            .clip(RoundedCornerShape(Yara.pillCorner))
            .background(Yara.field)
            .padding(4.dp)
    ) {
        labels.forEach { (filter, label) ->
            val active = filter == selected
            val bg by animateColorAsState(if (active) Yara.accent else Color.Transparent, tween(220), label = "seg")
            Box(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .clip(RoundedCornerShape(11.dp))
                    .background(bg)
                    .semantics { this.selected = active }
                    .clickable(role = Role.Tab) { onSelect(filter) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = TextStyle(
                        fontSize = 14.sp,
                        color = if (active) Color(0xFFD5F4EC) else Color.White.copy(alpha = 0.9f)
                    ),
                    maxLines = 1
                )
            }
        }
    }
}

@Composable
internal fun YaraAutoRow(checked: Boolean, onChange: (Boolean) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().height(48.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(painterResource(R.drawable.ic_y_swap), null, Modifier.size(20.dp), tint = Color.White.copy(alpha = 0.9f))
        Spacer(Modifier.width(10.dp))
        Text(
            stringResource(R.string.yara_auto_selection),
            Modifier.weight(1f),
            style = TextStyle(fontSize = 15.sp, color = Color.White),
            maxLines = 1
        )
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color(0xFFEAF7F3),
                checkedTrackColor = Yara.accent,
                checkedBorderColor = Color.Transparent,
                uncheckedThumbColor = Color(0xFF9FB3BC),
                uncheckedTrackColor = Yara.field,
                uncheckedBorderColor = Yara.stroke
            )
        )
    }
}

/** Rounded top sheet that holds the list, with the small grab handle and caption of the reference. */
@Composable
internal fun YaraSheet(
    modifier: Modifier = Modifier,
    content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit,
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Yara.sheet)
    ) {
        Box(
            Modifier
                .padding(top = 10.dp)
                .align(Alignment.CenterHorizontally)
                .size(width = 44.dp, height = 3.dp)
                .clip(CircleShape)
                .background(Yara.stroke)
        )
        Text(
            stringResource(R.string.yara_select_server),
            Modifier.padding(start = 16.dp, top = 14.dp, bottom = 10.dp),
            style = TextStyle(fontSize = 13.sp, color = Yara.textDim)
        )
        content()
    }
}

/** Subscription groups as small pills (only shown when there is more than one group). */
@Composable
internal fun YaraGroupChips(
    groups: List<GroupMapItem>,
    selectedIndex: Int,
    mainViewModel: MainViewModel,
    onTabClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        groups.forEachIndexed { index, group ->
            val flow = remember(group.id, mainViewModel) { mainViewModel.serversForGroup(group.id) }
            val servers by flow.collectAsStateWithLifecycle()
            val label = if (group.id.isEmpty()) group.remarks else "${group.remarks} (${servers.size})"
            val selected = index == selectedIndex
            val bg by animateColorAsState(if (selected) Yara.accent else Yara.field, tween(220), label = "chip")
            Box(
                Modifier
                    .heightIn(min = 36.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(bg)
                    .semantics { this.selected = selected }
                    .clickable(role = Role.Tab) { onTabClick(index) }
                    .padding(horizontal = 16.dp, vertical = 7.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = TextStyle(
                        fontSize = 13.sp,
                        color = if (selected) Color(0xFFD5F4EC) else Yara.textDim
                    ),
                    maxLines = 1, softWrap = false
                )
            }
        }
    }
}

// ───────────────────────────── Menus ─────────────────────────────

/** One drop-down with the import actions followed by the "more" actions (diamond button on Home). */
@Composable
internal fun YaraActionsMenu(
    expanded: Boolean,
    onDismiss: () -> Unit,
    onImport: (MainAction) -> Unit,
    onMore: (MainMoreMenuAction) -> Unit,
) {
    val scroll = rememberScrollState()
    val maxH = LocalConfiguration.current.screenHeightDp.dp - 120.dp
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        scrollState = scroll,
        containerColor = Yara.surfaceHigh,
        modifier = Modifier.heightIn(max = maxH)
    ) {
        ImportMenuContent(onAction = { action -> onDismiss(); onImport(action) })
        HorizontalDivider(color = Yara.stroke)
        MoreMenuContent { action -> onDismiss(); onMore(action) }
    }
}
