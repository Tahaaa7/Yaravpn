package com.v2ray.ang.ui.main

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.R
import com.v2ray.ang.dto.GroupMapItem
import com.v2ray.ang.ui.compose.Yara
import kotlinx.coroutines.delay
import java.util.Locale
import kotlin.math.abs

/** The three in-app pages reachable from the bottom tab menu (the 4th tab opens the drawer). */
internal enum class YaraTab { Home, Test, Servers }

/** What the big connect ring is showing. */
internal enum class ConnectVisual { Idle, Connecting, Connected }

// ───────────────────────────── Header ─────────────────────────────

/** Figma header: round menu button, centered title, round trailing button. */
@Composable
internal fun YaraHeader(
    title: String,
    onMenu: () -> Unit,
    modifier: Modifier = Modifier,
    trailing: @Composable () -> Unit,
) {
    Row(
        modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 14.dp)
            .height(60.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        HeaderCircle(R.drawable.ic_mp_hamburger, stringResource(R.string.acc_open_menu), onMenu)
        Text(
            title,
            Modifier.weight(1f),
            style = TextStyle(fontSize = 17.sp, fontWeight = FontWeight.SemiBold, color = Color.White),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        trailing()
    }
}

@Composable
internal fun HeaderCircle(iconRes: Int, desc: String?, onClick: () -> Unit) {
    Box(
        Modifier
            .size(44.dp)
            .clip(CircleShape)
            .background(Yara.circle)
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(painterResource(iconRes), desc, Modifier.size(20.dp), tint = Color.White)
    }
}

// ───────────────────────────── Bottom tab menu ─────────────────────────────

/** Figma "Tab Menu": #2D2D2D bar, the active tab is a purple circle. */
@Composable
internal fun YaraTabBar(
    selected: YaraTab,
    onSelect: (YaraTab) -> Unit,
    onMenu: () -> Unit,
    modifier: Modifier = Modifier,
) {
    Box(
        modifier
            .fillMaxWidth()
            .background(Yara.tabBar)
            .navigationBarsPadding()
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(70.dp)
                .padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TabItem(R.drawable.ic_y_home, stringResource(R.string.yara_tab_home), selected == YaraTab.Home) {
                onSelect(YaraTab.Home)
            }
            TabItem(R.drawable.ic_mp_speed, stringResource(R.string.yara_tab_test), selected == YaraTab.Test) {
                onSelect(YaraTab.Test)
            }
            TabItem(R.drawable.ic_y_grid, stringResource(R.string.yara_tab_servers), selected == YaraTab.Servers) {
                onSelect(YaraTab.Servers)
            }
            TabItem(R.drawable.ic_y_user, stringResource(R.string.yara_tab_menu), false, onMenu)
        }
    }
}

@Composable
private fun TabItem(iconRes: Int, label: String, selected: Boolean, onClick: () -> Unit) {
    val bg by animateColorAsState(if (selected) Yara.accent else Color.Transparent, tween(220), label = "tab-bg")
    val tint by animateColorAsState(
        if (selected) Color.White else Color.White.copy(alpha = 0.7f), tween(220), label = "tab-tint"
    )
    Box(
        Modifier
            .size(52.dp)
            .clip(CircleShape)
            .semantics(mergeDescendants = true) {
                contentDescription = label
                role = Role.Tab
                this.selected = selected
            }
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Box(
            Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(bg),
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(iconRes), null, Modifier.size(22.dp), tint = tint)
        }
    }
}

// ───────────────────────────── Buttons & cards ─────────────────────────────

/** Figma primary button: 50dp tall, 11dp radius, #9475FF. */
@Composable
internal fun YaraPrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    container: Color = Yara.accent,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.98f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "btn-scale"
    )
    Box(
        modifier
            .fillMaxWidth()
            .height(50.dp)
            .scale(scale)
            .clip(RoundedCornerShape(Yara.buttonCorner))
            .background(if (enabled) container else Yara.surfaceHigh)
            .clickable(
                interactionSource = src,
                indication = null,
                enabled = enabled,
                role = Role.Button,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = TextStyle(
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = if (enabled) Color.White else Yara.textMuted
            ),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Secondary (outlined) button used under the primary one. */
@Composable
internal fun YaraSecondaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .fillMaxWidth()
            .height(50.dp)
            .clip(RoundedCornerShape(Yara.buttonCorner))
            .background(Yara.surface)
            .border(1.dp, Yara.stroke, RoundedCornerShape(Yara.buttonCorner))
            .clickable(role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            style = TextStyle(fontSize = 15.sp, fontWeight = FontWeight.Medium, color = Color.White),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Selected-server card (Figma "Card", #303030, 10dp radius). Tapping it opens the server list. */
@Composable
internal fun YaraServerCard(
    summary: SelectedServerSummary?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val name = summary?.remarks?.takeIf { it.isNotBlank() } ?: stringResource(R.string.yara_no_server)
    val subtitle = summary?.protocol ?: stringResource(R.string.yara_selected_server)
    val changeLabel = stringResource(R.string.yara_change_server)
    Row(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(Yara.cardCorner))
            .background(Yara.surfaceHigh)
            .clickable(onClickLabel = changeLabel, role = Role.Button, onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ServerThumb(
            seed = summary?.guid?.hashCode() ?: 0,
            label = summary?.protocol?.take(5) ?: "Y",
            spinning = summary != null,
            size = 48.dp
        )
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                name,
                style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color.White),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.height(2.dp))
            Text(
                subtitle,
                style = TextStyle(fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (summary != null && summary.delayMillis > 0L) {
            SignalBars(summary.delayMillis)
            Spacer(Modifier.width(12.dp))
        }
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Yara.accent),
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(R.drawable.ic_y_chevron_right), null, Modifier.size(18.dp), tint = Color.White)
        }
    }
}

/** Figma stat card: round colored icon, value (16sp), label (12sp, 70% white). */
@Composable
internal fun YaraStatCard(
    iconRes: Int,
    tint: Color,
    value: String,
    label: String,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .clip(RoundedCornerShape(Yara.cardCorner))
            .background(Yara.surface)
            .padding(horizontal = 14.dp, vertical = 14.dp)
            .semantics(mergeDescendants = true) { },
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(tint),
            contentAlignment = Alignment.Center
        ) {
            Icon(painterResource(iconRes), null, Modifier.size(16.dp), tint = Color.White)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                value,
                style = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Color.White),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                label,
                style = TextStyle(fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)),
                maxLines = 1
            )
        }
    }
}

/** Figma "You are connected" box: small label + value on #1E1E1E. */
@Composable
internal fun YaraInfoCard(
    label: String,
    value: String,
    onClick: (() -> Unit)?,
    modifier: Modifier = Modifier,
) {
    val base = modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(Yara.cardCorner))
        .background(Yara.surface)
    val clickable = if (onClick != null) base.clickable(role = Role.Button, onClick = onClick) else base
    Column(
        clickable.padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            label,
            style = TextStyle(fontSize = 12.sp, color = Color.White.copy(alpha = 0.7f)),
            maxLines = 1
        )
        Spacer(Modifier.height(4.dp))
        Text(
            value,
            style = TextStyle(
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = Color.White,
                textAlign = TextAlign.Center
            ),
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Four-bar signal icon; the number of lit bars follows the measured latency. */
@Composable
internal fun SignalBars(delayMs: Long, modifier: Modifier = Modifier) {
    val level = when {
        delayMs <= 0L -> 0
        delayMs <= 250L -> 4
        delayMs <= 500L -> 3
        delayMs <= 900L -> 2
        else -> 1
    }
    val lit = when {
        level >= 3 -> Yara.green
        level == 2 -> Yara.amber
        else -> Yara.red
    }
    val off = Yara.textMuted.copy(alpha = 0.45f)
    Canvas(modifier.size(width = 18.dp, height = 16.dp)) {
        val barW = size.width / 7f
        for (i in 0 until 4) {
            val h = size.height * (0.35f + 0.65f * (i / 3f))
            drawRoundRect(
                color = if (i < level) lit else off,
                topLeft = Offset(i * barW * 2f, size.height - h),
                size = Size(barW, h),
                cornerRadius = CornerRadius(barW / 2f, barW / 2f)
            )
        }
    }
}

// ───────────────────────────── Connect ring ─────────────────────────────

/**
 * The hero of the home screen. Idle: dark disc with a power icon. Connecting: spinning gradient arc and the
 * purple stop square from the Figma "connecting" frame. Connected: purple ring with a soft glow, timer inside.
 */
@Composable
internal fun YaraConnectRing(
    visual: ConnectVisual,
    timerText: String,
    statusLabel: String,
    hint: String,
    actionLabel: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "ring")
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing), RepeatMode.Restart),
        label = "spin"
    )
    val pulse by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2200, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val ringColor by animateColorAsState(
        if (visual == ConnectVisual.Idle) Yara.stroke else Yara.accent, tween(350), label = "ring-color"
    )
    Box(
        modifier
            .size(232.dp)
            .clip(CircleShape)
            .clickable(onClickLabel = actionLabel, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val outer = 104.dp.toPx()
            if (visual == ConnectVisual.Connected) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(Yara.accent.copy(alpha = 0.30f), Color.Transparent),
                        center = c, radius = outer * 1.2f
                    ),
                    radius = outer * 1.2f, center = c
                )
                drawCircle(
                    Yara.accent.copy(alpha = (1f - pulse) * 0.35f),
                    radius = outer + pulse * 12.dp.toPx(), center = c,
                    style = Stroke(width = 2.dp.toPx())
                )
            }
            drawCircle(Yara.surface, radius = outer, center = c)
            drawCircle(
                ringColor, radius = outer, center = c,
                style = Stroke(width = if (visual == ConnectVisual.Connected) 3.dp.toPx() else 2.dp.toPx())
            )
            if (visual == ConnectVisual.Connecting) {
                rotate(spin, pivot = c) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            0f to Color.Transparent,
                            0.7f to Yara.blue,
                            1f to Yara.accent,
                            center = c
                        ),
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        topLeft = Offset(c.x - outer, c.y - outer),
                        size = Size(outer * 2f, outer * 2f),
                        style = Stroke(width = 4.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }
            drawCircle(Yara.bg, radius = outer - 24.dp.toPx(), center = c)
            drawCircle(
                Yara.stroke.copy(alpha = 0.6f), radius = outer - 24.dp.toPx(), center = c,
                style = Stroke(width = 1.dp.toPx())
            )
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            when (visual) {
                ConnectVisual.Idle -> {
                    Icon(painterResource(R.drawable.ic_mp_power), null, Modifier.size(56.dp), tint = Yara.accent)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        hint,
                        style = TextStyle(fontSize = 13.sp, color = Yara.textDim),
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                }

                ConnectVisual.Connecting -> {
                    Box(
                        Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Yara.accent)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        statusLabel,
                        style = TextStyle(fontSize = 14.sp, color = Color.White.copy(alpha = 0.7f)),
                        maxLines = 1
                    )
                }

                ConnectVisual.Connected -> {
                    Icon(painterResource(R.drawable.ic_mp_shield_check), null, Modifier.size(34.dp), tint = Yara.green)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        timerText,
                        style = TextStyle(fontSize = 26.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                    )
                    Text(
                        statusLabel,
                        style = TextStyle(fontSize = 13.sp, color = Color.White.copy(alpha = 0.7f)),
                        maxLines = 1
                    )
                }
            }
        }
    }
}

/** HH:MM:SS since the connection started; ticks once per second while [active]. */
@Composable
internal fun rememberElapsedText(sinceMs: Long, active: Boolean): String {
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active, sinceMs) {
        while (active) {
            now = System.currentTimeMillis()
            delay(1000)
        }
    }
    val secs = if (active && sinceMs > 0L) ((now - sinceMs) / 1000L).coerceAtLeast(0L) else 0L
    return String.format(Locale.US, "%02d:%02d:%02d", secs / 3600, (secs % 3600) / 60, secs % 60)
}

// ───────────────────────────── Latency gauge (Test page) ─────────────────────────────

/** Gauge ring that fills with the measured latency (full ring = 1000 ms or more). */
@Composable
internal fun YaraLatencyGauge(
    delayMs: Long,
    testing: Boolean,
    valueText: String,
    caption: String,
    modifier: Modifier = Modifier,
) {
    val fraction = if (delayMs > 0L) (delayMs / 1000f).coerceIn(0.04f, 1f) else 0f
    val animated by animateFloatAsState(fraction, tween(600), label = "gauge")
    val color = when {
        delayMs <= 0L -> Yara.accent
        delayMs <= 250L -> Yara.green
        delayMs <= 600L -> Yara.blue
        delayMs <= 1000L -> Yara.amber
        else -> Yara.red
    }
    val transition = rememberInfiniteTransition(label = "gauge-spin")
    val spin by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart),
        label = "gauge-spin-a"
    )
    Box(modifier.size(210.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val c = center
            val r = 96.dp.toPx()
            val tl = Offset(c.x - r, c.y - r)
            val sz = Size(r * 2f, r * 2f)
            drawCircle(Yara.surface, radius = r + 6.dp.toPx(), center = c)
            drawArc(
                color = Yara.surfaceHigh, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = tl, size = sz, style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
            )
            if (testing) {
                rotate(spin, pivot = c) {
                    drawArc(
                        color = Yara.accent, startAngle = 0f, sweepAngle = 70f, useCenter = false,
                        topLeft = tl, size = sz, style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            } else if (animated > 0f) {
                drawArc(
                    color = color, startAngle = 135f, sweepAngle = 270f * animated, useCenter = false,
                    topLeft = tl, size = sz, style = Stroke(width = 10.dp.toPx(), cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                valueText,
                style = TextStyle(fontSize = 34.sp, fontWeight = FontWeight.SemiBold, color = Color.White),
                maxLines = 1
            )
            Text(
                caption,
                style = TextStyle(fontSize = 13.sp, color = Yara.textDim),
                maxLines = 1
            )
        }
    }
}

// ───────────────────────────── Search bar (servers page) ─────────────────────────────

/** Figma "Search Tab": #303030 pill + a round purple button (here: add / import). */
@Composable
internal fun YaraSearchBar(
    query: String,
    onChange: (String) -> Unit,
    onAdd: () -> Unit,
    addMenu: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            Modifier
                .weight(1f)
                .height(50.dp)
                .clip(RoundedCornerShape(Yara.pillCorner))
                .background(Yara.surfaceHigh),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                painterResource(R.drawable.ic_mp_search), null,
                Modifier
                    .padding(start = 16.dp)
                    .size(20.dp),
                tint = Color.White.copy(alpha = 0.7f)
            )
            Box(
                Modifier
                    .weight(1f)
                    .padding(horizontal = 10.dp)
            ) {
                if (query.isEmpty()) {
                    Text(
                        stringResource(R.string.search_configs),
                        style = TextStyle(fontSize = 14.sp, color = Color.White.copy(alpha = 0.7f)),
                        maxLines = 1
                    )
                }
                BasicTextField(
                    value = query,
                    onValueChange = onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = SolidColor(Yara.accent),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (query.isNotEmpty()) {
                IconButton(onClick = { onChange("") }, Modifier.size(44.dp)) {
                    Icon(
                        painterResource(R.drawable.ic_mp_close), stringResource(R.string.acc_back),
                        Modifier.size(18.dp), tint = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }
        Spacer(Modifier.width(10.dp))
        Box {
            Box(
                Modifier
                    .size(50.dp)
                    .clip(CircleShape)
                    .background(Yara.accent)
                    .clickable(role = Role.Button, onClick = onAdd),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    painterResource(R.drawable.ic_mp_add), stringResource(R.string.acc_add),
                    Modifier.size(24.dp), tint = Color.White
                )
            }
            addMenu()
        }
    }
}

/** Subscription groups as scrolling pills; the selected one is filled purple. */
@Composable
internal fun YaraGroupChips(
    groups: List<GroupMapItem>,
    selectedIndex: Int,
    mainViewModel: MainViewModel,
    onTabClick: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    Row(
        modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        groups.forEachIndexed { index, group ->
            val flow = remember(group.id, mainViewModel) { mainViewModel.serversForGroup(group.id) }
            val servers by flow.collectAsStateWithLifecycle()
            val label = if (group.id.isEmpty()) group.remarks else "${group.remarks} (${servers.size})"
            val selected = index == selectedIndex
            val bg by animateColorAsState(if (selected) Yara.accent else Yara.surface, tween(220), label = "chip-bg")
            Box(
                Modifier
                    .heightIn(min = 40.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(bg)
                    .semantics { this.selected = selected }
                    .clickable(role = Role.Tab, onClick = { onTabClick(index) })
                    .padding(horizontal = 18.dp, vertical = 9.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label,
                    style = TextStyle(
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (selected) Color.White else Yara.textDim
                    ),
                    maxLines = 1,
                    softWrap = false
                )
            }
        }
    }
}

// ───────────────────────────── Drop-down menus ─────────────────────────────

@Composable
internal fun ImportDropdown(expanded: Boolean, onDismiss: () -> Unit, onAction: (MainAction) -> Unit) {
    val scroll = rememberScrollState()
    val maxH = LocalConfiguration.current.screenHeightDp.dp - 120.dp
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        scrollState = scroll,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.heightIn(max = maxH)
    ) {
        ImportMenuContent(onAction = { action -> onDismiss(); onAction(action) })
    }
}

@Composable
internal fun MoreDropdown(expanded: Boolean, onDismiss: () -> Unit, onSelected: (MainMoreMenuAction) -> Unit) {
    val scroll = rememberScrollState()
    val maxH = LocalConfiguration.current.screenHeightDp.dp - 120.dp
    DropdownMenu(
        expanded = expanded,
        onDismissRequest = onDismiss,
        scrollState = scroll,
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = Modifier.heightIn(max = maxH)
    ) {
        MoreMenuContent { action -> onDismiss(); onSelected(action) }
    }
}

// ───────────────────────────── Server avatar ─────────────────────────────

private val avatarPalette = listOf(
    listOf(Color(0xFF9475FF), Color(0xFF5ABAFF)),
    listOf(Color(0xFF5ABAFF), Color(0xFF3FD1D1)),
    listOf(Color(0xFFB36BFF), Color(0xFFFF7AD9)),
    listOf(Color(0xFF6C7DFF), Color(0xFF9475FF)),
)

/** Round gradient avatar with the protocol initials (the Figma design shows a flag here). */
@Composable
internal fun ServerThumb(seed: Int, label: String, spinning: Boolean, size: Dp) {
    val colors = avatarPalette[abs(seed) % avatarPalette.size]
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(colors))
            .then(if (spinning) Modifier.border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label.uppercase(),
            style = TextStyle(
                fontSize = (size.value * 0.27f).sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            ),
            maxLines = 1
        )
    }
}
