package com.v2ray.ang.ui.worker

import android.os.Bundle
import android.text.TextUtils
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.lifecycleScope
import com.v2ray.ang.AppConfig
import com.v2ray.ang.R
import com.v2ray.ang.dto.entities.SubscriptionCache
import com.v2ray.ang.dto.entities.SubscriptionItem
import com.v2ray.ang.extension.toast
import com.v2ray.ang.extension.toastError
import com.v2ray.ang.extension.toastSuccess
import com.v2ray.ang.handler.AngConfigManager
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.ui.base.BaseComponentActivity
import com.v2ray.ang.ui.compose.AppTopBar
import com.v2ray.ang.ui.compose.FormTextField
import com.v2ray.ang.ui.compose.NavigationBarsSpacer
import com.v2ray.ang.ui.compose.SettingsSwitchItem
import com.v2ray.ang.ui.compose.verticalScrollbar
import com.v2ray.ang.util.Utils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class WorkerHubActivity : BaseComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    @Composable
    override fun ScreenContent() {
        val stored = remember { loadStoredWorker() }
        var name by remember { mutableStateOf(stored.item.remarks.ifBlank { "YARA Worker" }) }
        var url by remember { mutableStateOf(stored.item.url) }
        var autoUpdate by remember { mutableStateOf(stored.item.autoUpdate) }
        var busy by remember { mutableStateOf(false) }
        var lastCount by remember { mutableStateOf(stored.count) }
        var lastUpdated by remember { mutableStateOf(stored.item.lastUpdated) }
        val scroll = rememberScrollState()

        Scaffold(
            topBar = {
                AppTopBar(
                    title = stringResource(R.string.title_worker_hub),
                    onBackClick = { finish() },
                    isLoading = busy
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .verticalScroll(scroll)
                    .verticalScrollbar(scroll)
            ) {
                Text(
                    text = stringResource(R.string.worker_hub_lead),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                )
                FormTextField(
                    label = stringResource(R.string.worker_hub_name),
                    value = name,
                    onValueChange = { name = it }
                )
                FormTextField(
                    label = stringResource(R.string.worker_hub_url),
                    value = url,
                    onValueChange = { url = it },
                    keyboardType = KeyboardType.Uri,
                    placeholder = "https://your-worker.workers.dev/sub"
                )
                SettingsSwitchItem(
                    title = stringResource(R.string.sub_auto_update),
                    checked = autoUpdate,
                    onCheckedChange = { autoUpdate = it }
                )
                Text(
                    text = stringResource(R.string.worker_hub_count, lastCount),
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )
                    if (lastUpdated > 0) {
                    Text(
                        text = stringResource(R.string.worker_hub_last_fetch) +
                            " " + java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(java.util.Date(lastUpdated)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        persistAndFetch(name, url, autoUpdate, fetchNow = true) { count, updated ->
                            lastCount = count
                            lastUpdated = updated
                            busy = false
                        }
                        busy = true
                    },
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(stringResource(R.string.worker_hub_fetch))
                }
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = {
                        persistAndFetch(name, url, autoUpdate, fetchNow = false) { count, updated ->
                            lastCount = count
                            lastUpdated = updated
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Text(stringResource(R.string.worker_hub_save))
                }
                NavigationBarsSpacer()
            }
        }
    }

    private data class StoredWorker(
        val guid: String,
        val item: SubscriptionItem,
        val count: Int
    )

    private fun loadStoredWorker(): StoredWorker {
        val guid = MmkvManager.decodeSettingsString(AppConfig.PREF_YARA_WORKER_ID).orEmpty()
        if (guid.isNotEmpty()) {
            val item = MmkvManager.decodeSubscription(guid)
            if (item != null) {
                return StoredWorker(guid, item, MmkvManager.decodeServerList(guid).size)
            }
        }
        val found = MmkvManager.decodeSubscriptions().firstOrNull {
            it.subscription.remarks.equals("YARA Worker", ignoreCase = true)
        }
        if (found != null) {
            MmkvManager.encodeSettings(AppConfig.PREF_YARA_WORKER_ID, found.guid)
            return StoredWorker(found.guid, found.subscription, MmkvManager.decodeServerList(found.guid).size)
        }
        return StoredWorker("", SubscriptionItem(remarks = "YARA Worker", autoUpdate = true), 0)
    }

    private fun expandWorkerUrls(url: String): List<String> {
        val out = linkedSetOf(url)
        try {
            val uri = java.net.URI(url)
            val path = uri.path?.trimEnd('/') ?: ""
            val hasQuery = !uri.query.isNullOrEmpty()
            val join = if (hasQuery) "&" else "?"
            if (path.isEmpty() || path == "/") {
                val base = url.trimEnd('/')
                out += "$base/sub"
                if (!url.contains("app=")) {
                    out += "$url${join}app=v2ray"
                    out += "$url${join}app=v2rayng"
                    out += "$base/sub?app=v2ray"
                }
            } else {
                if (!path.contains("sub", ignoreCase = true) && !url.contains("app=")) {
                    out += "${url.trimEnd('/')}/sub"
                    out += "$url${join}app=v2ray"
                }
            }
        } catch (_: Exception) {
            // keep original
        }
        return out.toList()
    }

    private fun persistAndFetch(
        name: String,
        url: String,
        autoUpdate: Boolean,
        fetchNow: Boolean,
        done: (Int, Long) -> Unit
    ) {
        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(url)) {
            toast(getString(R.string.worker_hub_missing_fields))
            done(0, 0)
            return
        }
        if (!Utils.isValidUrl(url) && !url.startsWith("http://")) {
            toastError(getString(R.string.worker_hub_invalid_url))
            done(0, 0)
            return
        }
        lifecycleScope.launch(Dispatchers.IO) {
            val stored = loadStoredWorker()
            val originalUrl = url.trim()
            val item = stored.item.apply {
                remarks = name.ifBlank { "YARA Worker" }
                this.url = originalUrl
                this.autoUpdate = autoUpdate
                enabled = true
                userAgent = "v2rayNG/2.3.9"
                allowInsecureUrl = originalUrl.startsWith("http://")
            }
            val guid = stored.guid.ifBlank { Utils.getUuid() }
            MmkvManager.encodeSubscription(guid, item)
            MmkvManager.encodeSettings(AppConfig.PREF_YARA_WORKER_ID, guid)
            var count = MmkvManager.decodeServerList(guid).size
            var updated = item.lastUpdated
            if (fetchNow) {
                var workingUrl = originalUrl
                for (candidate in expandWorkerUrls(originalUrl)) {
                    item.url = candidate
                    val result = AngConfigManager.updateConfigViaSub(SubscriptionCache(guid, item))
                    if (result.configCount > 0) {
                        count = result.configCount
                        workingUrl = candidate
                        break
                    }
                }
                item.url = workingUrl
                item.lastUpdated = System.currentTimeMillis()
                MmkvManager.encodeSubscription(guid, item)
                updated = item.lastUpdated
            }
            withContext(Dispatchers.Main) {
                if (fetchNow) {
                    if (count > 0) {
                        toastSuccess(getString(R.string.worker_hub_fetched, count))
                    } else {
                        toastError(getString(R.string.worker_hub_empty))
                    }
                } else {
                    toastSuccess(R.string.toast_success)
                }
                done(count, updated)
            }
        }
    }
}
