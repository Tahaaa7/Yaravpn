package com.v2ray.ang.ui.main

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import com.v2ray.ang.extension.toSpeedString
import com.v2ray.ang.handler.TrafficSample
import com.v2ray.ang.ui.compose.Yara

/**
 * Home: the Earth image behind the header, "Connected" + big timer, the power button
 * and the bottom card with the selected server and live download / upload speed.
 */
@Composable
internal fun YaraHomePage(
    visual: ConnectVisual,
    summary: SelectedServerSummary?,
    traffic: TrafficSample,
    onToggle: () -> Unit,
    onOpenServers: () -> Unit,
    onMenu: () -> Unit,
    onImport: (MainAction) -> Unit,
    onMore: (MainMoreMenuAction) -> Unit,
    modifier: Modifier = Modifier,
) {
    val connected = visual == ConnectVisual.Connected
    val timer = rememberElapsedText(traffic.connectedSinceMs, connected)
    val dash = "\u2014"
    val downText = if (connected) traffic.downBps.toSpeedString() else dash
    val upText = if (connected) traffic.upBps.toSpeedString() else dash
    val statusText = when (visual) {
        ConnectVisual.Connected -> stringResource(R.string.yara_connected)
        ConnectVisual.Connecting -> stringResource(R.string.yara_connecting)
        ConnectVisual.Idle -> stringResource(R.string.yara_not_connected)
    }
    val actionLabel = if (connected) stringResource(R.string.yara_disconnect) else stringResource(R.string.yara_connect)
    var showMenu by remember { mutableStateOf(false) }

    Box(modifier.fillMaxSize().background(Yara.bg)) {
        Image(
            painter = painterResource(R.drawable.yara_earth),
            contentDescription = null,
            modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter),
            contentScale = ContentScale.FillWidth
        )
        Column(Modifier.fillMaxSize()) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .height(56.dp)
                    .padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                HeaderIcon(R.drawable.ic_mp_hamburger, stringResource(R.string.acc_open_menu), onMenu)
                Spacer(Modifier.weight(1f))
                Box {
                    HeaderIcon(R.drawable.ic_y_diamond, stringResource(R.string.acc_more), { showMenu = true })
                    YaraActionsMenu(
                        expanded = showMenu,
                        onDismiss = { showMenu = false },
                        onImport = onImport,
                        onMore = onMore
                    )
                }
            }
            Spacer(Modifier.height(78.dp))
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (connected) {
                        Icon(
                            painterResource(R.drawable.ic_y_check), null,
                            Modifier.size(15.dp), tint = Color.White.copy(alpha = 0.75f)
                        )
                        Spacer(Modifier.width(5.dp))
                    }
                    Text(
                        statusText,
                        style = TextStyle(fontSize = 14.sp, color = Color.White.copy(alpha = 0.75f)),
                        maxLines = 1
                    )
                }
                Spacer(Modifier.height(2.dp))
                Text(
                    timer,
                    style = TextStyle(
                        fontSize = 56.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        letterSpacing = (-1).sp
                    ),
                    maxLines = 1
                )
            }
            Spacer(Modifier.height(36.dp))
            Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                YaraPowerButton(visual = visual, actionLabel = actionLabel, onClick = onToggle)
            }
            Spacer(Modifier.weight(1f))
            YaraHomeCard(
                summary = summary,
                downText = downText,
                upText = upText,
                onChange = onOpenServers,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(Modifier.height(20.dp))
            Spacer(Modifier.navigationBarsPadding())
        }
    }
}

/** "Select server": search, Global / Special / Selected, Auto Selection and the list sheet. */
@Composable
internal fun YaraServersPage(
    title: String,
    searchQuery: String,
    onSearch: (String) -> Unit,
    filter: ServerFilter,
    onFilter: (ServerFilter) -> Unit,
    autoSelect: Boolean,
    onAutoSelect: (Boolean) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    chips: @Composable () -> Unit,
    list: @Composable () -> Unit,
) {
    Column(modifier.fillMaxSize().background(Yara.bg)) {
        YaraServersHeader(title = title, onBack = onBack)
        Column(Modifier.padding(horizontal = 14.dp)) {
            YaraSearchField(query = searchQuery, onChange = onSearch)
            Spacer(Modifier.height(14.dp))
            YaraSegmented(selected = filter, onSelect = onFilter)
            Spacer(Modifier.height(6.dp))
            YaraAutoRow(checked = autoSelect, onChange = onAutoSelect)
            Spacer(Modifier.height(4.dp))
        }
        YaraSheet(Modifier.weight(1f)) {
            chips()
            Box(Modifier.weight(1f).fillMaxWidth()) { list() }
        }
    }
}
