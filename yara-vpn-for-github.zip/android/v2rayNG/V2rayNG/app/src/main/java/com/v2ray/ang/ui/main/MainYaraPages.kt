package com.v2ray.ang.ui.main

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.v2ray.ang.R
import com.v2ray.ang.extension.toSpeedString
import com.v2ray.ang.handler.TrafficSample
import com.v2ray.ang.ui.compose.Yara

/**
 * Home page (Figma frames 2, 3 and 5): selected server, big connect ring, status, live
 * download/upload cards and the main Connect / Disconnect button.
 */
@Composable
internal fun YaraHomePage(
    visual: ConnectVisual,
    statusText: String,
    summary: SelectedServerSummary?,
    traffic: TrafficSample,
    onToggle: () -> Unit,
    onTestConnection: () -> Unit,
    onOpenServers: () -> Unit,
    onMenu: () -> Unit,
    onMore: () -> Unit,
    moreMenu: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val connected = visual == ConnectVisual.Connected
    val timer = rememberElapsedText(traffic.connectedSinceMs, connected)
    val dash = "\u2014"
    val downText = if (connected) traffic.downBps.toSpeedString() else dash
    val upText = if (connected) traffic.upBps.toSpeedString() else dash
    val connectLabel = stringResource(R.string.yara_connect)
    val disconnectLabel = stringResource(R.string.yara_disconnect)
    val connectingLabel = stringResource(R.string.yara_connecting)
    val connectedLabel = stringResource(R.string.yara_connected)

    Column(modifier.fillMaxSize()) {
        YaraHeader(title = stringResource(R.string.app_name), onMenu = onMenu) {
            Box {
                HeaderCircle(R.drawable.ic_mp_more, stringResource(R.string.acc_more), onMore)
                moreMenu()
            }
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(4.dp))
            YaraServerCard(summary = summary, onClick = onOpenServers)
            Spacer(Modifier.height(16.dp))
            YaraConnectRing(
                visual = visual,
                timerText = timer,
                statusLabel = if (connected) connectedLabel else connectingLabel,
                hint = stringResource(R.string.yara_tap_to_connect),
                actionLabel = if (connected) disconnectLabel else connectLabel,
                onClick = onToggle
            )
            Spacer(Modifier.height(16.dp))
            YaraInfoCard(
                label = stringResource(R.string.yara_status),
                value = statusText,
                onClick = if (connected) onTestConnection else null
            )
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                YaraStatCard(
                    iconRes = R.drawable.ic_y_arrow_down,
                    tint = Yara.blue,
                    value = downText,
                    label = stringResource(R.string.yara_download),
                    modifier = Modifier.weight(1f)
                )
                YaraStatCard(
                    iconRes = R.drawable.ic_y_arrow_up,
                    tint = Yara.accent,
                    value = upText,
                    label = stringResource(R.string.yara_upload),
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(Modifier.height(12.dp))
        }
        Box(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            YaraPrimaryButton(
                text = when (visual) {
                    ConnectVisual.Idle -> connectLabel
                    ConnectVisual.Connecting -> connectingLabel
                    ConnectVisual.Connected -> disconnectLabel
                },
                onClick = onToggle,
                enabled = visual != ConnectVisual.Connecting
            )
        }
    }
}

/**
 * Speed page (Figma frame 4, adapted to what the core can measure): a latency gauge,
 * the selected server and the test actions.
 */
@Composable
internal fun YaraTestPage(
    status: MainStatus,
    statusText: String,
    summary: SelectedServerSummary?,
    isRunning: Boolean,
    isTesting: Boolean,
    onTestConnection: () -> Unit,
    onTestAll: () -> Unit,
    onSort: () -> Unit,
    onOpenServers: () -> Unit,
    onMenu: () -> Unit,
    onMore: () -> Unit,
    moreMenu: @Composable () -> Unit,
    modifier: Modifier = Modifier,
) {
    val measured = (status as? MainStatus.ConnectionTest)?.result?.delayMillis
    val delayMs = when {
        isRunning && measured != null -> measured
        else -> summary?.delayMillis ?: 0L
    }
    val testing = isTesting || status is MainStatus.Testing || status is MainStatus.TestProgress
    val valueText = if (delayMs > 0L) stringResource(R.string.server_test_delay_value, delayMs) else "\u2014"

    Column(modifier.fillMaxSize()) {
        YaraHeader(title = stringResource(R.string.yara_title_speed), onMenu = onMenu) {
            Box {
                HeaderCircle(R.drawable.ic_mp_more, stringResource(R.string.acc_more), onMore)
                moreMenu()
            }
        }
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(4.dp))
            YaraServerCard(summary = summary, onClick = onOpenServers)
            Spacer(Modifier.height(20.dp))
            YaraLatencyGauge(
                delayMs = delayMs,
                testing = testing,
                valueText = valueText,
                caption = stringResource(R.string.yara_latency)
            )
            Spacer(Modifier.height(20.dp))
            YaraInfoCard(
                label = stringResource(R.string.yara_status),
                value = if (isRunning) statusText else stringResource(R.string.yara_connect_to_test),
                onClick = null
            )
            Spacer(Modifier.height(12.dp))
        }
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            YaraPrimaryButton(
                text = if (isRunning) stringResource(R.string.yara_test_connection)
                else stringResource(R.string.yara_test_all),
                onClick = if (isRunning) onTestConnection else onTestAll
            )
            YaraSecondaryButton(text = stringResource(R.string.yara_sort_results), onClick = onSort)
        }
    }
}
