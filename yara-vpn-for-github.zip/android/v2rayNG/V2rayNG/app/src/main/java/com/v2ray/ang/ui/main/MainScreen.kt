package com.v2ray.ang.ui.main

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.ui.compose.DarkColor
import com.v2ray.ang.ui.compose.LocalDarkTheme
import com.v2ray.ang.ui.compose.Yara
import kotlinx.coroutines.delay
import com.v2ray.ang.ui.compose.QRCodeDialog
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    mainViewModel: MainViewModel,
    onAction: (MainAction) -> Unit,
    onNavigate: (MainDestination) -> Unit,
) {
    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
    val groups = uiState.groups
    val isLoading by mainViewModel.isLoading.collectAsStateWithLifecycle()
    val isRunning = uiState.isRunning
    val displayText = mainViewModel.formatStatus(uiState.status)
    val selectedGuid = uiState.selectedGuid
    val doubleColumnDisplay = uiState.doubleColumnDisplay
    val confirmRemove = uiState.confirmRemove
    val shareQRCodeBitmap = uiState.shareQRCodeBitmap

    val isDarkTheme = LocalDarkTheme.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showDelAllConfirm by remember { mutableStateOf(false) }
    var showDelDuplicateConfirm by remember { mutableStateOf(false) }
    var showDelInvalidConfirm by remember { mutableStateOf(false) }
    var showRemoveConfirm by rememberSaveable(stateSaver = ServerDeleteTarget.Saver) {
        mutableStateOf<ServerDeleteTarget?>(null)
    }

    var shareTarget by remember { mutableStateOf<Triple<String, ProfileItem, Boolean>?>(null) }
    val removeServer: (String, String) -> Unit = { guid, profileName ->
        if (confirmRemove) {
            showRemoveConfirm = ServerDeleteTarget(guid, profileName)
        } else {
            onAction(MainAction.RemoveServer(guid))
        }
    }

    val pagerState = rememberPagerState(
        initialPage = 0,
        pageCount = { groups.size.coerceAtLeast(1) }
    )

    val lazyListStates = remember { mutableStateMapOf<String, LazyListState>() }
    val lazyGridStates = remember { mutableStateMapOf<String, LazyGridState>() }

    LaunchedEffect(groups) {
        val validGroupIds = groups.map { it.id }.toSet()
        lazyListStates.keys.retainAll(validGroupIds)
        lazyGridStates.keys.retainAll(validGroupIds)
    }

    LaunchedEffect(groups, uiState.selectedGroupId) {
        if (groups.isEmpty()) return@LaunchedEffect
        val selectedIndex = groups.indexOfFirst { it.id == uiState.selectedGroupId }
            .takeIf { it >= 0 } ?: 0
        if (!pagerState.isScrollInProgress && pagerState.settledPage != selectedIndex) {
            pagerState.scrollToPage(selectedIndex)
        }
    }

    val latestGroups by rememberUpdatedState(groups)

    LaunchedEffect(pagerState) {
        snapshotFlow { pagerState.settledPage }
            .distinctUntilChanged()
            .collect { page ->
                val currentGroups = latestGroups
                if (page in currentGroups.indices) {
                    onAction(MainAction.SelectGroup(currentGroups[page].id))
                }
            }
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val ctrl = WindowCompat.getInsetsController(window, view)
            ctrl.isAppearanceLightStatusBars = false
            ctrl.isAppearanceLightNavigationBars = false
        }
    }

    val traffic by mainViewModel.traffic.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(YaraTab.Home.ordinal) }
    val currentTab = YaraTab.entries[tab.coerceIn(0, YaraTab.entries.size - 1)]

    // "Connecting" is a UI-only phase: from the tap until the service reports running (or fails / times out).
    var connecting by remember { mutableStateOf(false) }
    LaunchedEffect(isRunning) { connecting = false }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(15_000)
            connecting = false
        }
    }
    val visual = when {
        isRunning -> ConnectVisual.Connected
        connecting -> ConnectVisual.Connecting
        else -> ConnectVisual.Idle
    }
    val toggle: () -> Unit = {
        if (!isRunning) connecting = true
        onAction(MainAction.ToggleService)
    }
    val summary = remember(selectedGuid, uiState.status, groups) { mainViewModel.selectedServerSummary(selectedGuid) }

    CompositionLocalProvider(LocalDarkTheme provides true) {
    MaterialTheme(
        colorScheme = DarkColor.copy(background = Yara.bg),
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes
    ) {
    MainDialogs(
        showDelAllConfirm = showDelAllConfirm,
        onDismissDelAll = { showDelAllConfirm = false },
        onConfirmDelAll = { showDelAllConfirm = false; onAction(MainAction.RemoveAllServers) },
        showDelDuplicateConfirm = showDelDuplicateConfirm,
        onDismissDelDuplicate = { showDelDuplicateConfirm = false },
        onConfirmDelDuplicate = { showDelDuplicateConfirm = false; onAction(MainAction.RemoveDuplicateServers) },
        showDelInvalidConfirm = showDelInvalidConfirm,
        onDismissDelInvalid = { showDelInvalidConfirm = false },
        onConfirmDelInvalid = { showDelInvalidConfirm = false; onAction(MainAction.RemoveInvalidServers) },
        showRemoveConfirm = showRemoveConfirm,
        onDismissRemove = { showRemoveConfirm = null },
        onConfirmRemove = { guid -> showRemoveConfirm = null; onAction(MainAction.RemoveServer(guid)) }
    )

    if (shareTarget != null) {
        val (guid, profile, more) = shareTarget!!
        ShareMethodDialog(
            guid = guid,
            profile = profile,
            more = more,
            onDismiss = { shareTarget = null },
            onAction = onAction,
            onRemove = removeServer,
        )
    }
    if (shareQRCodeBitmap != null) {
        QRCodeDialog(bitmap = shareQRCodeBitmap, onDismiss = { onAction(MainAction.DismissQRCodeDialog) })
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            MainDrawerContent(
                drawerState = drawerState,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    onNavigate(route)
                }
            )
        }
    ) {
        val navBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
        val currentIndex = pagerState.currentPage.coerceIn(0, (groups.size - 1).coerceAtLeast(0))
        var showImportMenu by remember { mutableStateOf(false) }
        var showMoreMenu by remember { mutableStateOf(false) }
        val openDrawer: () -> Unit = { scope.launch { drawerState.open() } }

        val moreMenu: @Composable () -> Unit = {
            MoreDropdown(
                expanded = showMoreMenu,
                onDismiss = { showMoreMenu = false },
                onSelected = { action ->
                    when (action) {
                        MainMoreMenuAction.RestartService -> onAction(MainAction.RestartService)
                        MainMoreMenuAction.DeleteAll -> showDelAllConfirm = true
                        MainMoreMenuAction.DeleteDuplicate -> showDelDuplicateConfirm = true
                        MainMoreMenuAction.DeleteInvalid -> showDelInvalidConfirm = true
                        MainMoreMenuAction.ExportAll -> onAction(MainAction.ExportAll)
                        MainMoreMenuAction.LocateSelected -> onAction(MainAction.LocateSelectedServer)
                        MainMoreMenuAction.SortByTestResults -> onAction(MainAction.SortByTestResults)
                        MainMoreMenuAction.TestAll -> onAction(MainAction.TestAllServers)
                        MainMoreMenuAction.TestAllRealPing -> onAction(MainAction.TestRealAllServers)
                        MainMoreMenuAction.UpdateSubscriptions -> onAction(MainAction.UpdateSubscriptions)
                    }
                }
            )
        }

        Box(
            Modifier
                .fillMaxSize()
                .background(Yara.bg)
        ) {
            Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (currentTab) {
                        YaraTab.Home -> YaraHomePage(
                            visual = visual,
                            statusText = displayText,
                            summary = summary,
                            traffic = traffic,
                            onToggle = toggle,
                            onTestConnection = { onAction(MainAction.TestCurrentServer) },
                            onOpenServers = { tab = YaraTab.Servers.ordinal },
                            onMenu = openDrawer,
                            onMore = { showMoreMenu = true },
                            moreMenu = moreMenu,
                        )

                        YaraTab.Test -> YaraTestPage(
                            status = uiState.status,
                            statusText = displayText,
                            summary = summary,
                            isRunning = isRunning,
                            isTesting = uiState.isTesting,
                            onTestConnection = { onAction(MainAction.TestCurrentServer) },
                            onTestAll = { onAction(MainAction.TestRealAllServers) },
                            onSort = { onAction(MainAction.SortByTestResults) },
                            onOpenServers = { tab = YaraTab.Servers.ordinal },
                            onMenu = openDrawer,
                            onMore = { showMoreMenu = true },
                            moreMenu = moreMenu,
                        )

                        YaraTab.Servers -> Column(Modifier.fillMaxSize()) {
                            YaraHeader(
                                title = stringResource(R.string.yara_title_servers),
                                onMenu = openDrawer
                            ) {
                                Box {
                                    HeaderCircle(R.drawable.ic_mp_more, stringResource(R.string.acc_more)) {
                                        showMoreMenu = true
                                    }
                                    moreMenu()
                                }
                            }
                            YaraSearchBar(
                                query = searchQuery,
                                onChange = { q ->
                                    searchQuery = q
                                    onAction(MainAction.Search(q))
                                },
                                onAdd = { showImportMenu = true },
                                addMenu = {
                                    ImportDropdown(
                                        expanded = showImportMenu,
                                        onDismiss = { showImportMenu = false },
                                        onAction = onAction
                                    )
                                }
                            )
                            if (groups.isNotEmpty()) {
                                YaraGroupChips(
                                    groups = groups,
                                    selectedIndex = currentIndex,
                                    mainViewModel = mainViewModel,
                                    onTabClick = { targetIndex ->
                                        scope.launch {
                                            pagerState.navigateToPageOptimized(
                                                targetPage = targetIndex,
                                                animateAdjacentPage = true
                                            )
                                        }
                                    }
                                )
                            }
                            if (isLoading) {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp)
                                        .height(2.dp),
                                    color = Yara.accent,
                                    trackColor = Color.Transparent
                                )
                            }
                            HorizontalPager(
                                state = pagerState,
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                userScrollEnabled = true,
                                beyondViewportPageCount = 1,
                                key = { page -> groups.getOrNull(page)?.id ?: "group-page-$page" }
                            ) { page ->
                                val group = groups.getOrNull(page) ?: return@HorizontalPager
                                GroupPagerPage(
                                    groupId = group.id,
                                    mainViewModel = mainViewModel,
                                    selectedGuid = selectedGuid,
                                    locateTarget = uiState.locateTarget,
                                    doubleColumnDisplay = doubleColumnDisplay,
                                    searchQuery = searchQuery,
                                    lazyListStates = lazyListStates,
                                    lazyGridStates = lazyGridStates,
                                    onSelectServer = { guid -> onAction(MainAction.SelectServer(guid)) },
                                    onEditServer = { guid, profile -> onAction(MainAction.EditServer(guid, profile)) },
                                    onShareServer = { guid, profile ->
                                        shareTarget = Triple(guid, profile, false)
                                    },
                                    onMoreServer = { guid, profile ->
                                        shareTarget = Triple(guid, profile, true)
                                    },
                                    onRemoveServer = removeServer,
                                    contentPadding = PaddingValues(
                                        start = 0.dp,
                                        top = 2.dp,
                                        end = 0.dp,
                                        bottom = 16.dp
                                    )
                                )
                            }
                        }
                    }
                }
                YaraTabBar(
                    selected = currentTab,
                    onSelect = { tab = it.ordinal },
                    onMenu = openDrawer
                )
            }
        }
    }
    } // MaterialTheme
    } // CompositionLocalProvider
}
