package com.v2ray.ang.ui.main

import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.v2ray.ang.handler.MmkvManager
import com.v2ray.ang.R
import androidx.compose.ui.res.stringResource
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.v2ray.ang.dto.entities.ProfileItem
import com.v2ray.ang.ui.compose.DarkColor
import com.v2ray.ang.ui.compose.LocalDarkTheme
import com.v2ray.ang.ui.compose.Yara
import kotlinx.coroutines.delay
import com.v2ray.ang.ui.compose.QRCodeDialog
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

@Composable
fun MainScreen(
    mainViewModel: MainViewModel,
    onAction: (MainAction) -> Unit,
    onNavigate: (MainDestination) -> Unit,
) {
    val uiState by mainViewModel.uiState.collectAsStateWithLifecycle()
    val groups = uiState.groups
    val isLoading by mainViewModel.isLoading.collectAsStateWithLifecycle()
    val isRunning = uiState.isRunning
    val displayText = mainViewModel.formatStatus(uiState.status)
    val selectedGuid = uiState.selectedGuid
    val doubleColumnDisplay = uiState.doubleColumnDisplay
    val confirmRemove = uiState.confirmRemove
    val shareQRCodeBitmap = uiState.shareQRCodeBitmap

    val isDarkTheme = LocalDarkTheme.current
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    var showSearch by remember { mutableStateOf(false) }
    var searchQuery by remember { mutableStateOf("") }
    var showDelAllConfirm by remember { mutableStateOf(false) }
    var showDelDuplicateConfirm by remember { mutableStateOf(false) }
    var showDelInvalidConfirm by remember { mutableStateOf(false) }
    var showRemoveConfirm by rememberSaveable(stateSaver = ServerDeleteTarget.Saver) {
        mutableStateOf<ServerDeleteTarget?>(null)
    }

    var shareTarget by remember { mutableStateOf<Triple<String, ProfileItem, Boolean>?>(null) }
    val removeServer: (String, String) -> Unit = { guid, profileName ->
        if (confirmRemove) {
            showRemoveConfirm = ServerDeleteTarget(guid, profileName)
        } else {
            onAction(MainAction.RemoveServer(guid))
        }
    }

    val lazyListStates = remember { mutableStateMapOf<String, LazyListState>() }
    val lazyGridStates = remember { mutableStateMapOf<String, LazyGridState>() }

    LaunchedEffect(groups) {
        val validGroupIds = groups.map { it.id }.toSet()
        lazyListStates.keys.retainAll { it.substringBefore('#') in validGroupIds }
        lazyGridStates.keys.retainAll { it.substringBefore('#') in validGroupIds }
    }

    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val ctrl = WindowCompat.getInsetsController(window, view)
            ctrl.isAppearanceLightStatusBars = false
            ctrl.isAppearanceLightNavigationBars = false
        }
    }

    val traffic by mainViewModel.traffic.collectAsStateWithLifecycle()
    val favorites by mainViewModel.favorites.collectAsStateWithLifecycle()
    val autoSelect by mainViewModel.autoSelect.collectAsStateWithLifecycle()
    var serversOpen by rememberSaveable { mutableStateOf(false) }
    var filterOrdinal by rememberSaveable { mutableIntStateOf(ServerFilter.Global.ordinal) }
    val filter = ServerFilter.entries[filterOrdinal.coerceIn(0, ServerFilter.entries.size - 1)]
    // Global / Special / Selected are three real, swipeable pages.
    val filterPager = rememberPagerState(
        initialPage = filterOrdinal,
        pageCount = { ServerFilter.entries.size }
    )
    LaunchedEffect(filterPager) {
        snapshotFlow { filterPager.currentPage }
            .distinctUntilChanged()
            .collect { filterOrdinal = it }
    }

    // "Connecting" is a UI-only phase: from the tap until the service reports running (or fails / times out).
    var connecting by remember { mutableStateOf(false) }
    LaunchedEffect(isRunning) { connecting = false }
    LaunchedEffect(connecting) {
        if (connecting) {
            delay(15_000)
            connecting = false
        }
    }
    val visual = when {
        isRunning -> ConnectVisual.Connected
        connecting -> ConnectVisual.Connecting
        else -> ConnectVisual.Idle
    }
    val toggle: () -> Unit = {
        if (!isRunning) {
            mainViewModel.applyAutoSelection()
            connecting = true
        }
        onAction(MainAction.ToggleService)
    }
    val summary = remember(selectedGuid, uiState.status, groups) { mainViewModel.selectedServerSummary(selectedGuid) }

    BackHandler(enabled = serversOpen) { serversOpen = false }

    CompositionLocalProvider(LocalDarkTheme provides true) {
    MaterialTheme(
        colorScheme = DarkColor.copy(background = Yara.bg),
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes
    ) {
    MainDialogs(
        showDelAllConfirm = showDelAllConfirm,
        onDismissDelAll = { showDelAllConfirm = false },
        onConfirmDelAll = { showDelAllConfirm = false; onAction(MainAction.RemoveAllServers) },
        showDelDuplicateConfirm = showDelDuplicateConfirm,
        onDismissDelDuplicate = { showDelDuplicateConfirm = false },
        onConfirmDelDuplicate = { showDelDuplicateConfirm = false; onAction(MainAction.RemoveDuplicateServers) },
        showDelInvalidConfirm = showDelInvalidConfirm,
        onDismissDelInvalid = { showDelInvalidConfirm = false },
        onConfirmDelInvalid = { showDelInvalidConfirm = false; onAction(MainAction.RemoveInvalidServers) },
        showRemoveConfirm = showRemoveConfirm,
        onDismissRemove = { showRemoveConfirm = null },
        onConfirmRemove = { guid -> showRemoveConfirm = null; onAction(MainAction.RemoveServer(guid)) }
    )

    if (shareTarget != null) {
        val (guid, profile, more) = shareTarget!!
        ShareMethodDialog(
            guid = guid,
            profile = profile,
            more = more,
            onDismiss = { shareTarget = null },
            onAction = onAction,
            onRemove = removeServer,
        )
    }
    if (shareQRCodeBitmap != null) {
        QRCodeDialog(bitmap = shareQRCodeBitmap, onDismiss = { onAction(MainAction.DismissQRCodeDialog) })
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        gesturesEnabled = !serversOpen,
        drawerContent = {
            MainDrawerContent(
                drawerState = drawerState,
                onNavigate = { route ->
                    scope.launch { drawerState.close() }
                    onNavigate(route)
                }
            )
        }
    ) {
        val currentIndex = groups.indexOfFirst { it.id == uiState.selectedGroupId }.coerceAtLeast(0)
        val currentGroupId = groups.getOrNull(currentIndex)?.id ?: uiState.selectedGroupId
        val onMoreAction: (MainMoreMenuAction) -> Unit = { action ->
            when (action) {
                MainMoreMenuAction.RestartService -> onAction(MainAction.RestartService)
                MainMoreMenuAction.DeleteAll -> showDelAllConfirm = true
                MainMoreMenuAction.DeleteDuplicate -> showDelDuplicateConfirm = true
                MainMoreMenuAction.DeleteInvalid -> showDelInvalidConfirm = true
                MainMoreMenuAction.ExportAll -> onAction(MainAction.ExportAll)
                MainMoreMenuAction.LocateSelected -> onAction(MainAction.LocateSelectedServer)
                MainMoreMenuAction.SortByTestResults -> onAction(MainAction.SortByTestResults)
                MainMoreMenuAction.TestAll -> onAction(MainAction.TestAllServers)
                MainMoreMenuAction.TestAllRealPing -> onAction(MainAction.TestRealAllServers)
                MainMoreMenuAction.UpdateSubscriptions -> onAction(MainAction.UpdateSubscriptions)
            }
        }

        Box(Modifier.fillMaxSize().background(Yara.bg)) {
            if (!serversOpen) {
                YaraHomePage(
                    visual = visual,
                    summary = summary,
                    traffic = traffic,
                    onToggle = toggle,
                    onOpenServers = { serversOpen = true },
                    onMenu = { scope.launch { drawerState.open() } },
                    onImport = onAction,
                    onMore = onMoreAction,
                )
            } else {
                YaraServersPage(
                    title = stringResource(R.string.yara_select_server),
                    searchQuery = searchQuery,
                    onSearch = { q ->
                        searchQuery = q
                        onAction(MainAction.Search(q))
                    },
                    filter = filter,
                    onFilter = { scope.launch { filterPager.animateScrollToPage(it.ordinal) } },
                    autoSelect = autoSelect,
                    onAutoSelect = mainViewModel::setAutoSelect,
                    onBack = { serversOpen = false },
                    chips = {
                        if (groups.size > 1) {
                            YaraGroupChips(
                                groups = groups,
                                selectedIndex = currentIndex,
                                mainViewModel = mainViewModel,
                                onTabClick = { targetIndex ->
                                    groups.getOrNull(targetIndex)?.let { onAction(MainAction.SelectGroup(it.id)) }
                                }
                            )
                        }
                    },
                    list = {
                        Column(Modifier.fillMaxSize()) {
                            if (isLoading) {
                                LinearProgressIndicator(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 14.dp)
                                        .height(2.dp),
                                    color = Yara.accent,
                                    trackColor = Color.Transparent
                                )
                            }
                            HorizontalPager(
                                state = filterPager,
                                modifier = Modifier.weight(1f).fillMaxWidth(),
                                beyondViewportPageCount = 1,
                                key = { page -> "filter-page-$page" }
                            ) { page ->
                                GroupPagerPage(
                                    groupId = currentGroupId,
                                    mainViewModel = mainViewModel,
                                    selectedGuid = selectedGuid,
                                    locateTarget = if (page == ServerFilter.Global.ordinal) uiState.locateTarget else null,
                                    doubleColumnDisplay = false,
                                    searchQuery = searchQuery,
                                    lazyListStates = lazyListStates,
                                    lazyGridStates = lazyGridStates,
                                    onSelectServer = { guid -> onAction(MainAction.SelectServer(guid)) },
                                    onEditServer = { guid, profile -> onAction(MainAction.EditServer(guid, profile)) },
                                    onShareServer = { guid, profile ->
                                        shareTarget = Triple(guid, profile, false)
                                    },
                                    onMoreServer = { guid, profile ->
                                        shareTarget = Triple(guid, profile, true)
                                    },
                                    onRemoveServer = removeServer,
                                    filter = ServerFilter.entries[page],
                                    favorites = favorites,
                                    onToggleFavorite = mainViewModel::toggleFavorite,
                                    contentPadding = PaddingValues(top = 2.dp, bottom = 24.dp)
                                )
                            }
                        }
                    }
                )
            }
        }
    }
    } // MaterialTheme
    } // CompositionLocalProvider
}
