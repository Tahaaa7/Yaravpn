package com.v2ray.ang.ui.main

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.v2ray.ang.R
import com.v2ray.ang.ui.compose.YaraBlue
import com.v2ray.ang.ui.compose.YaraCyan
import com.v2ray.ang.ui.compose.glass

/**
 * Hero section of the home screen: one big glowing connect orb with the YARA emblem,
 * live status, and the selected server as a glass pill.
 */
@Composable
fun MainHero(
    isRunning: Boolean,
    statusText: String,
    serverName: String?,
    onToggle: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val transition = rememberInfiniteTransition(label = "hero")
    val pulse by transition.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    val sweep by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing), RepeatMode.Restart),
        label = "sweep"
    )
    val breathe by transition.animateFloat(
        initialValue = 0.97f, targetValue = 1.03f,
        animationSpec = infiniteRepeatable(tween(1800), RepeatMode.Reverse),
        label = "breathe"
    )
    val accent = if (isRunning) YaraCyan else Color(0xFF6C7A99)
    val orb = 168

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(top = 6.dp, bottom = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            modifier = Modifier.size((orb + 56).dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.size((orb + 56).dp)) {
                val c = Offset(size.width / 2, size.height / 2)
                val base = orb.dp.toPx() / 2
                if (isRunning) {
                    // expanding sonar rings
                    for (i in 0..1) {
                        val p = (pulse + i * 0.5f) % 1f
                        drawCircle(
                            color = YaraCyan.copy(alpha = (1f - p) * 0.35f),
                            radius = base + p * 28.dp.toPx(),
                            center = c,
                            style = Stroke(width = 2.dp.toPx())
                        )
                    }
                }
                // soft glow
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(accent.copy(alpha = if (isRunning) 0.45f else 0.18f), Color.Transparent),
                        center = c, radius = base * 1.45f
                    ),
                    radius = base * 1.45f, center = c
                )
                // rotating gradient arc
                drawArc(
                    brush = Brush.sweepGradient(
                        listOf(Color.Transparent, accent, YaraBlue, Color.Transparent),
                        center = c
                    ),
                    startAngle = if (isRunning) sweep else -90f,
                    sweepAngle = if (isRunning) 300f else 40f,
                    useCenter = false,
                    topLeft = Offset(c.x - base - 8.dp.toPx(), c.y - base - 8.dp.toPx()),
                    size = Size((base + 8.dp.toPx()) * 2, (base + 8.dp.toPx()) * 2),
                    style = Stroke(width = 3.5.dp.toPx(), cap = StrokeCap.Round)
                )
            }
            Box(
                modifier = Modifier
                    .size(orb.dp)
                    .scale(if (isRunning) breathe else 1f)
                    .glass(shape = CircleShape, strong = true)
                    .background(
                        Brush.radialGradient(
                            listOf(accent.copy(alpha = 0.28f), Color.Transparent)
                        ),
                        CircleShape
                    )
                    .clip(CircleShape)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        onClick = onToggle
                    ),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(R.drawable.yara_emblem),
                    contentDescription = null,
                    modifier = Modifier.size((orb * 0.62f).dp),
                    alpha = if (isRunning) 1f else 0.6f
                )
            }
        }

        Text(
            text = statusText,
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 16.sp),
            color = if (isRunning) YaraCyan else MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 24.dp)
        )

        if (!serverName.isNullOrBlank()) {
            Text(
                text = serverName,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .padding(horizontal = 32.dp)
                    .glass(shape = RoundedCornerShape(50))
                    .padding(horizontal = 18.dp, vertical = 8.dp)
            )
        }
    }
}
