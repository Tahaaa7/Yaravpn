# Yara

A branded fork of [v2rayNG](https://github.com/2dust/v2rayNG) (GPL-3.0).

- Application id: `com.yara.vpn`
- Dark teal UI
- Dedicated **Worker** hub: save a Worker URL, fetch configs, auto-add, update
- Core capabilities of v2rayNG / Xray preserved

See [../YARA-BUILD.md](../YARA-BUILD.md) for Android Studio build steps.
