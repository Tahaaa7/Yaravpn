# YARA VPN — Android Studio

Fork of official [v2rayNG](https://github.com/2dust/v2rayNG) (GPL-3.0).
Package: `com.yara.vpn` · Version 1.0.0

## Open in Android Studio

1. Open folder `android/v2rayNG/V2rayNG`
2. Use JDK 17
3. Sync Gradle

## Xray core (required for a real APK)

v2rayNG loads the core from `app/libs/*.aar`.

```bash
git clone --depth 1 https://github.com/2dust/AndroidLibXrayLite.git
# follow that repo to produce libv2ray.aar
# copy the AAR into V2rayNG/app/libs/
```

Also init the `hev-socks5-tunnel` submodule if you need TUN:

```bash
cd android/v2rayNG
git submodule update --init --recursive
```

Build:

```bash
cd android/v2rayNG/V2rayNG
./gradlew assemblePlaystoreRelease
```

APK output: `app/build/outputs/apk/`

## Worker

Drawer → **Worker / ورکر**

- Save Worker URL (Cloudflare Worker or subscription)
- Fetch configs (uses the same v2rayNG subscription engine)
- Auto-add to the server list
- Update later from the same screen
- Address is stored in MMKV (`pref_yara_worker_id`)

Supported Worker responses: Base64 subscription, vless/vmess/trojan/ss/hy2 links, JSON, Clash.
