# Yara — راهنمای بیلد

Package: `com.yara.vpn` · Version `1.0.0`

---

## بیلد اندروید با GitHub Actions (پیشنهادی)

بدون نصب Android Studio روی سیستم خودت:

### ۱) ریپو را روی GitHub بگذار

```bash
cd project   # ریشه همین پروژه
git init
git add .
git commit -m "Yara 1.0.0"
git branch -M main
git remote add origin https://github.com/YOUR_USER/yara-vpn.git
git push -u origin main
```

> اگر فقط پوشه اندروید را می‌خواهی:  
> `android/v2rayNG` را ریشه ریپو کن؛ workflow داخل  
> `android/v2rayNG/.github/workflows/build-yara.yml` اجرا می‌شود.

### ۲) بیلد را اجرا کن

1. در GitHub برو به تب **Actions**
2. workflow به نام **Build YARA Android APK** را انتخاب کن
3. **Run workflow** بزن (نوع `release` یا `debug`)
4. بعد از اتمام، از بخش **Artifacts** فایل `yara-vpn-apk` را دانلود کن

Workflow خودکار:
- ساب‌ماژول `hev-socks5-tunnel` را می‌گیرد و native می‌سازد
- `libv2ray.aar` را از ریلیز رسمی [AndroidLibXrayLite](https://github.com/2dust/AndroidLibXrayLite/releases) دانلود می‌کند
- `assemblePlaystoreRelease` / `Debug` را اجرا می‌کند

### ۳) (اختیاری) امضای Release

در GitHub → **Settings → Secrets and variables → Actions** این secretها را بساز:

| Secret | مقدار |
|--------|--------|
| `APP_KEYSTORE_BASE64` | خروجی `base64 -w0 your.keystore` |
| `APP_KEYSTORE_PASSWORD` | رمز keystore |
| `APP_KEYSTORE_ALIAS` | alias کلید |
| `APP_KEY_PASSWORD` | رمز کلید |

بدون این‌ها هم APK ساخته می‌شود (برای تست؛ نصب روی گوشی ممکن است نیاز به «منابع ناشناس» داشته باشد).

ساخت base64 از keystore:

```bash
base64 -w0 my-release.jks > keystore.b64
# محتوای keystore.b64 را در secret بگذار
```

---

## بیلد محلی اندروید

### پیش‌نیاز
- JDK 17
- Android SDK
- فایل `libv2ray.aar`

```bash
# هسته Xray
# از ریلیز دانلود کن یا خودت بساز:
# https://github.com/2dust/AndroidLibXrayLite/releases
mkdir -p android/v2rayNG/V2rayNG/app/libs
# libv2ray.aar را داخل app/libs کپی کن

cd android/v2rayNG
git submodule update --init --recursive
# یا:
# git clone --depth 1 https://github.com/heiher/hev-socks5-tunnel.git hev-socks5-tunnel
export NDK_HOME=/path/to/ndk
bash compile-hevtun.sh
cp -a libs/. V2rayNG/app/libs/

cd V2rayNG
./gradlew assemblePlaystoreRelease
```

خروجی: `V2rayNG/app/build/outputs/apk/`

Android Studio: پوشه `android/v2rayNG/V2rayNG` را باز کن → Sync → Build.

---

## وب‌اپ

```bash
npm install
npm run dev      # http://0.0.0.0:8080
npm run build
```

---

## ویژگی‌های YARA

- Drawer → **Worker / ورکر** (اشتراک / Cloudflare Worker)
- **جعل SNI دستی** در تنظیمات (دامنه دلخواه)
- فرگمنت، Mux، عبور ایران / LAN
- رابط فارسی / انگلیسی

---

## ساختار مهم

```
.github/workflows/build-android.yml   ← بیلد وقتی ریشه ریپو کل پروژه است
android/v2rayNG/
  .github/workflows/build-yara.yml    ← بیلد وقتی ریشه ریپو فقط اندروید است
  compile-hevtun.sh
  V2rayNG/app/libs/                   ← libv2ray.aar + .so های tun
```
