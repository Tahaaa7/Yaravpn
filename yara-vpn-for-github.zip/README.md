# YARA VPN — بیلد با GitHub از روی ZIP

## مراحل (خیلی ساده)

### ۱) ریپو بساز
در GitHub یک Repository جدید و **خالی** بساز (بدون README).

### ۲) ZIP را آپلود کن
یکی از این دو روش:

**روش A — با Git (پیشنهادی):**
```bash
unzip yara-vpn-for-github.zip -d yara-vpn
cd yara-vpn
git init
git add .
git commit -m "YARA VPN"
git branch -M main
git remote add origin https://github.com/USER/REPO.git
git push -u origin main
```

**روش B — از سایت GitHub:**
- Add file → Upload files
- محتویات ZIP را بکش و رها کن
- Commit changes

### ۳) بیلد بگیر
1. تب **Actions**
2. **Build YARA APK** را باز کن
3. **Run workflow** بزن (release یا debug)
4. صبر کن تا سبز شود
5. پایین صفحه **Artifacts** → **yara-vpn-apk** را دانلود کن

APK داخل همان zip آرتیفکت است.

### نکات
- نیازی به نصب Android Studio نیست
- `libv2ray.aar` و tun را خود workflow می‌گیرد
- برای امضای رسمی، Secrets را طبق `BUILD.md` اضافه کن

Package: `com.yara.vpn` · Version 1.0.0
